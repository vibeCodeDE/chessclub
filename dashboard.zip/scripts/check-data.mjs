import 'dotenv/config';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { eq, inArray } from 'drizzle-orm';
import { db, pool } from '../src/db/index.ts';
import { activities, announcements, contributions, events, members, payments, registrations, requests, settings } from '../src/db/schema.ts';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
const base = 'http://127.0.0.1:3000';
const read = async () => (await page.request.get(base + '/api/club')).json();
const original = await read();
const marker = 'Browsercheck ' + Date.now();
const createdMemberIds = [], createdEventIds = [], createdAnnouncementIds = [];
const reviewed = original.requests.find((r) => r.status === 'Offen');
let requestTouched = false;
const mutate = async (action, payload, status = 200) => {
  const response = await page.request.post(base + '/api/club', { data: { action, payload } });
  assert.equal(response.status(), status, await response.text());
  return response.json();
};
const openNew = async (name) => {
  await page.getByRole('button', { name: 'Neu anlegen', exact: true }).click();
  await page.locator('.new-menu button').filter({ hasText: name }).click();
  await page.getByRole('dialog').waitFor();
};
const submit = async (name) => {
  await page.getByRole('dialog').getByRole('button', { name, exact: true }).click();
  await page.getByRole('dialog').waitFor({ state: 'hidden' });
};

try {
  await page.goto(base, { waitUntil: 'networkidle' });
  await openNew('Mitglied hinzufügen');
  await page.getByLabel('Vollständiger Name').fill(marker);
  await page.getByLabel('E-Mail-Adresse', { exact: false }).fill('browsercheck-' + Date.now() + '@example.de');
  await page.getByLabel('Beitragskategorie', { exact: true }).selectOption('Erwachsene');
  await submit('Mitglied hinzufügen');
  let data = await read();
  const member = data.members.find((m) => m.name === marker);
  assert.ok(member, 'Member was not persisted');
  createdMemberIds.push(member.id);
  assert.equal(data.members.length, original.members.length + 1);
  const due = data.contributions.find((c) => c.memberId === member.id);
  assert.equal(due.totalCents, 9000);
  await page.reload({ waitUntil: 'networkidle' });
  await page.getByRole('textbox', { name: 'Verein durchsuchen' }).fill(marker);
  await page.locator('.search-results button').first().click();
  await page.getByLabel('Telefonnummer').fill('0176 55512345');
  await submit('Änderungen speichern');
  data = await read();
  assert.equal(data.members.find((m) => m.id === member.id).phone, '0176 55512345');
  console.log('PASS: Create member, automatic annual contribution, edit profile and reload persistence');

  await page.locator('.nav-item').filter({ hasText: /^Beiträge & Kasse$/ }).click();
  await page.getByRole('textbox', { name: 'Beiträge durchsuchen' }).fill(marker);
  await page.getByRole('button', { name: `Zahlung für ${marker} buchen`, exact: true }).click();
  await page.getByLabel('Jetzt buchen').fill('10.00');
  await submit('Zahlung buchen');
  data = await read();
  assert.equal(data.contributions.find((c) => c.id === due.id).paidCents, 1000);
  assert.equal(data.payments.find((p) => p.memberId === member.id).amountCents, 1000);
  await mutate('book-payment', { contributionId: due.id, amountCents: 8001 }, 400);
  await mutate('book-payment', { contributionId: due.id, amountCents: 0 }, 400);
  const repeat = await mutate('run-contributions', { year: 2026 });
  assert.equal(repeat.data.contributions.length, data.contributions.length);
  console.log('PASS: Partial payment, persistent ledger, overpayment protection and idempotent annual billing');

  await openNew('Termin erstellen');
  await page.getByLabel('Titel des Termins').fill(marker + ' Turnier');
  await page.getByLabel('Terminart', { exact: true }).selectOption('Turnier');
  await page.getByLabel('Datum', { exact: false }).fill('2026-10-10');
  await page.getByLabel('Beginn').fill('18:00');
  await page.getByLabel('Ort', { exact: false }).fill('Vereinsheim');
  await submit('Termin erstellen');
  data = await read();
  const event = data.events.find((e) => e.title === marker + ' Turnier');
  assert.ok(event);
  createdEventIds.push(event.id);
  await page.locator('.nav-item').filter({ hasText: /^Kalender$/ }).click();
  await page.locator('.calendar-event').filter({ hasText: marker }).click();
  await page.getByRole('button', { name: 'Ich bin dabei', exact: true }).click();
  await page.getByRole('button', { name: 'Anmeldung zurücknehmen', exact: true }).waitFor();
  data = await read();
  assert.ok(data.registrations.includes(event.id));
  assert.equal(data.events.find((e) => e.id === event.id).attendees, 1);
  const calendarDownload = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Kalenderdatei', exact: true }).click();
  assert.equal((await calendarDownload).suggestedFilename(), 'Vereinstermin.ics');
  await page.getByRole('button', { name: 'Anmeldung zurücknehmen', exact: true }).click();
  await page.getByRole('button', { name: 'Ich bin dabei', exact: true }).waitFor();
  data = await read();
  assert.ok(!data.registrations.includes(event.id));
  assert.equal(data.events.find((e) => e.id === event.id).attendees, 0);
  await page.getByRole('button', { name: 'Dialog schließen' }).click();
  console.log('PASS: Create event, join, withdraw and export calendar file');

  if (reviewed) {
    await page.locator('.nav-item').filter({ hasText: /^Änderungswünsche/ }).click();
    await page.locator('.request-card').filter({ hasText: reviewed.newValue }).getByRole('button', { name: 'Anfrage prüfen' }).click();
    requestTouched = true;
    await submit('Änderung freigeben');
    data = await read();
    assert.equal(data.requests.find((r) => r.id === reviewed.id).status, 'Genehmigt');
    assert.equal(data.members.find((m) => m.id === reviewed.memberId)[reviewed.field], reviewed.newValue);
    await mutate('resolve-request', { id: reviewed.id, decision: 'Genehmigt' }, 400);
    console.log('PASS: Review request, update member data, prevent duplicate approval');
  }

  await openNew('Ankündigung schreiben');
  await page.getByLabel('Überschrift').fill(marker + ' Nachricht');
  await page.getByLabel('Deine Nachricht').fill('Eine temporäre Nachricht für den automatisierten Funktionstest.');
  await submit('Veröffentlichen');
  data = await read();
  const announcement = data.announcements.find((a) => a.title === marker + ' Nachricht');
  assert.ok(announcement);
  createdAnnouncementIds.push(announcement.id);
  await page.locator('.nav-item').filter({ hasText: /^Ankündigungen/ }).click();
  await page.locator('.announcement-card').filter({ hasText: marker }).getByRole('button', { name: 'Ankündigung lesen' }).click();
  assert.ok((await page.getByRole('dialog').textContent()).includes('temporäre Nachricht'));
  await page.getByRole('button', { name: 'Alles klar' }).click();
  console.log('PASS: Publish and read announcements');

  await page.getByRole('button', { name: 'Einstellungen', exact: true }).click();
  await page.getByLabel('Vereinsname').fill(original.settings.clubName + ' Test');
  await submit('Einstellungen speichern');
  data = await read();
  assert.equal(data.settings.clubName, original.settings.clubName + ' Test');
  await mutate('save-settings', { ...original.settings, notifications: original.settings.notifications === 'true' });
  const csv = await page.request.get(base + '/api/export?type=members');
  assert.equal(csv.status(), 200);
  assert.ok((await csv.text()).includes(marker));
  await mutate('nonexistent-action', {}, 400);
  await mutate('create-member', { name: 'Invalid', email: 'not-an-email', category: 'Erwachsene' }, 400);
  console.log('PASS: Persist settings, export live member data and reject invalid input');
} finally {
  const latest = await read();
  const activityIds = latest.activities.filter((a) => !original.activities.some((o) => o.id === a.id)).map((a) => a.id);
  const tempMemberIds = [...new Set([...createdMemberIds, ...latest.members.filter((m) => m.name === marker).map((m) => m.id)])];
  const tempEventIds = [...new Set([...createdEventIds, ...latest.events.filter((e) => e.title.startsWith(marker)).map((e) => e.id)])];
  const tempAnnouncementIds = [...new Set([...createdAnnouncementIds, ...latest.announcements.filter((a) => a.title.startsWith(marker)).map((a) => a.id)])];
  await db.transaction(async (tx) => {
    if (tempMemberIds.length) {
      await tx.delete(payments).where(inArray(payments.memberId, tempMemberIds));
      await tx.delete(contributions).where(inArray(contributions.memberId, tempMemberIds));
      await tx.delete(members).where(inArray(members.id, tempMemberIds));
    }
    if (tempEventIds.length) {
      await tx.delete(registrations).where(inArray(registrations.eventId, tempEventIds));
      await tx.delete(events).where(inArray(events.id, tempEventIds));
    }
    if (tempAnnouncementIds.length) await tx.delete(announcements).where(inArray(announcements.id, tempAnnouncementIds));
    if (activityIds.length) await tx.delete(activities).where(inArray(activities.id, activityIds));
    if (requestTouched && reviewed) {
      await tx.update(requests).set({ status: reviewed.status }).where(eq(requests.id, reviewed.id));
      const originalMember = original.members.find((m) => m.id === reviewed.memberId);
      await tx.update(members).set({ [reviewed.field]: originalMember[reviewed.field] }).where(eq(members.id, reviewed.memberId));
    }
    for (const [key, value] of Object.entries(original.settings)) await tx.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
  });
  const restored = await read();
  assert.equal(restored.members.length, original.members.length);
  assert.equal(restored.contributions.length, original.contributions.length);
  assert.equal(restored.payments.length, original.payments.length);
  assert.equal(restored.events.length, original.events.length);
  assert.equal(restored.announcements.length, original.announcements.length);
  console.log('PASS: Temporary test records removed; original club data restored');
  await browser.close();
  await pool.end();
}
