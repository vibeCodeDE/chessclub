import { getClubData } from "@/lib/data";
import { ClubApp } from "@/components/club-app";
import type { View } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function HomePage({ searchParams }: { searchParams: Promise<{ view?: string }> }) {
  const [data, params] = await Promise.all([getClubData(), searchParams]);
  const views: View[] = ["overview", "members", "finance", "games", "calendar", "announcements", "requests", "club", "activity"];
  const view = views.includes(params.view as View) ? params.view as View : "overview";
  return <ClubApp initialData={data} initialView={view} />;
}
