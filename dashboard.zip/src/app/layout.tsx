import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Übersicht · Schachclubmanager",
  description: "Mehr Zeit fürs Schach. Mitglieder, Beiträge und Spielbetrieb für deinen Verein – an einem Ort.",
  applicationName: "Schachclubmanager",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
