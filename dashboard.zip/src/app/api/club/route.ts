import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { activities, announcements, contributions, events, members, payments, registrations, requests, settings } from "@/db/schema";
import { ensureSeeded, getClubData } from "@/lib/data";
import { annualFees, categories, euro } from "@/lib/utils";

export const dynamic = "force-dynamic";
class InputError extends Error {}
const id = () => randomUUID();
const text = (value: unknown, label: string, max = 200, required = true) => {
  if (typeof value !== "string" || (required && !value.trim()) || value.length > max) throw new InputError(`${label} ist ungültig. Bitte prüfe deine Eingabe.`);
  return value.trim();
};
const yearValue = (value: unknown) => {
  const year = Number(value);
  if (!Number.isInteger(year) || year < 2020 || year > 2040) throw new InputError("Bitte wähle ein gültiges Beitragsjahr.");
  return year;
};
const validEmail = (value: unknown) => {
  const email = text(value, "Die E-Mail-Adresse", 254);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new InputError("Bitte gib eine gültige E-Mail-Adresse ein.");
  return email;
};
const dateValue = (value: unknown) => {
  const date = text(value, "Das Datum", 10);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(Date.parse(date)) || new Date(date).toISOString().slice(0, 10) !== date) throw new InputError("Bitte gib ein gültiges Datum ein.");
  return date;
};
const log = (title: string, description: string, type: string) => ({ id: id(), title, description, type, createdAt: new Date(Math.max(Date.now(), Date.parse("2026-09-30T12:00:00Z"))).toISOString() });

export async function GET() {
  try { return NextResponse.json(await getClubData()); }
  catch (error) { console.error("Club read error", error); return NextResponse.json({ error: "Die Vereinsdaten konnten nicht geladen werden." }, { status: 500 }); }
}

export async function POST(request: Request) {
  try {
    await ensureSeeded();
    let body;
    try { body = await request.json(); } catch { throw new InputError("Ungültige Anfrage."); }
    if (!body || typeof body !== "object" || !body.payload || typeof body.payload !== "object" || Array.isArray(body.payload)) throw new InputError("Ungültige Anfrage.");
    const p: Record<string, unknown> = body.payload;
    let message = "Änderungen gespeichert.";

    if (body.action === "create-member" || body.action === "update-member") {
      const category = text(p.category, "Die Beitragskategorie");
      if (!(categories as readonly string[]).includes(category)) throw new InputError("Bitte wähle eine Beitragskategorie.");
      const status = text(p.status ?? "Aktiv", "Der Status");
      if (!["Aktiv", "Passiv"].includes(status)) throw new InputError("Ungültiger Mitgliedsstatus.");
      const rating = Number(p.rating ?? 0);
      if (!Number.isInteger(rating) || rating < 0 || rating > 3500) throw new InputError("Die DWZ muss zwischen 0 und 3500 liegen.");
      const values = {
        name: text(p.name, "Der Name", 100), email: validEmail(p.email), category, status,
        phone: text(p.phone ?? "", "Die Telefonnummer", 50, false),
        address: text(p.address ?? "", "Die Adresse", 200, false),
        joinedAt: dateValue(p.joinedAt ?? new Date().toISOString().slice(0, 10)), rating,
      };
      await db.transaction(async (tx) => {
        if (body.action === "create-member") {
          const memberId = id();
          const year = yearValue(p.year ?? 2026);
          await tx.insert(members).values({ id: memberId, ...values, color: ["sage", "sand", "blue", "rose"][Math.floor(Math.random() * 4)] });
          await tx.insert(contributions).values({ id: id(), memberId, year, totalCents: annualFees[category], dueDate: `${year}-12-31` });
          await tx.insert(activities).values(log("Ein neues Gesicht im Verein", `${values.name} wurde als Mitglied aufgenommen.`, "member"));
          message = `${values.name} ist jetzt Mitglied. Herzlich willkommen!`;
        } else {
          const memberId = text(p.id, "Die Mitgliedsnummer");
          const updated = await tx.update(members).set(values).where(eq(members.id, memberId)).returning();
          if (!updated.length) throw new InputError("Dieses Mitglied wurde nicht gefunden.");
          await tx.insert(activities).values(log("Mitgliedsdaten aktualisiert", `Die Daten von ${values.name} wurden aktualisiert.`, "member"));
          message = "Mitgliedsdaten gespeichert.";
        }
      });
    } else if (body.action === "book-payment") {
      const contributionId = text(p.contributionId, "Der Beitrag");
      const amount = Number(p.amountCents);
      if (!Number.isInteger(amount) || amount <= 0 || amount > 10000000) throw new InputError("Bitte gib einen gültigen, positiven Betrag ein.");
      const method = text(p.method ?? "Überweisung", "Die Zahlungsart");
      if (!["Überweisung", "Barzahlung", "Lastschrift"].includes(method)) throw new InputError("Ungültige Zahlungsart.");
      await db.transaction(async (tx) => {
        const [due] = await tx.select().from(contributions).where(eq(contributions.id, contributionId)).for("update");
        if (!due) throw new InputError("Dieser Beitrag wurde nicht gefunden.");
        if (amount > due.totalCents - due.paidCents) throw new InputError("Der Betrag ist höher als der noch offene Beitrag.");
        const [person] = await tx.select().from(members).where(eq(members.id, due.memberId));
        await tx.update(contributions).set({ paidCents: due.paidCents + amount }).where(eq(contributions.id, contributionId));
        await tx.insert(payments).values({ id: id(), contributionId, memberId: due.memberId, amountCents: amount, method });
        await tx.insert(activities).values(log("Beitrag eingegangen", `${person.name} · ${euro(amount)} gebucht`, "payment"));
        message = `${euro(amount)} für ${person.name} erfolgreich gebucht.`;
      });
    } else if (body.action === "resolve-request") {
      const requestId = text(p.id, "Die Anfrage");
      const decision = text(p.decision, "Die Entscheidung");
      if (!["Genehmigt", "Abgelehnt"].includes(decision)) throw new InputError("Ungültige Entscheidung.");
      await db.transaction(async (tx) => {
        const [change] = await tx.select().from(requests).where(eq(requests.id, requestId)).for("update");
        if (!change || change.status !== "Offen") throw new InputError("Diese Anfrage wurde bereits bearbeitet.");
        if (decision === "Genehmigt") {
          if (!["email", "address", "phone"].includes(change.field)) throw new InputError("Dieses Feld kann nicht geändert werden.");
          await tx.update(members).set({ [change.field]: change.newValue }).where(eq(members.id, change.memberId));
        }
        await tx.update(requests).set({ status: decision }).where(eq(requests.id, requestId));
        const [person] = await tx.select().from(members).where(eq(members.id, change.memberId));
        await tx.insert(activities).values(log(decision === "Genehmigt" ? "Änderung freigegeben" : "Änderung abgelehnt", `${person.name} · Stammdatenanfrage bearbeitet`, "request"));
      });
      message = decision === "Genehmigt" ? "Anfrage freigegeben. Die Mitgliedsdaten wurden aktualisiert." : "Anfrage abgelehnt. Die bisherigen Daten bleiben erhalten.";
    } else if (body.action === "create-event") {
      const time = text(p.time, "Die Uhrzeit", 5);
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new InputError("Bitte gib eine gültige Uhrzeit ein.");
      const type = text(p.type, "Die Terminart");
      if (!["Mannschaft", "Turnier", "Vereinsabend", "Training", "Sonstiges"].includes(type)) throw new InputError("Ungültige Terminart.");
      const title = text(p.title, "Der Titel", 160);
      await db.transaction(async (tx) => {
        await tx.insert(events).values({ id: id(), title, type, date: dateValue(p.date), time, location: text(p.location, "Der Ort", 200), description: text(p.description ?? "", "Die Beschreibung", 5000, false), status: type === "Turnier" ? "Anmeldung offen" : "Geplant", team: text(p.team ?? "", "Die Mannschaft", 100, false) });
        await tx.insert(activities).values(log("Ein neuer Termin steht fest", title, "event"));
      });
      message = "Der Termin wurde im Vereinskalender angelegt.";
    } else if (body.action === "register-event") {
      const eventId = text(p.id, "Der Termin");
      await db.transaction(async (tx) => {
        const [event] = await tx.select().from(events).where(eq(events.id, eventId)).for("update");
        if (!event || event.status === "Entwurf") throw new InputError("Für diesen Termin ist noch keine Anmeldung möglich.");
        const [registration] = await tx.select().from(registrations).where(and(eq(registrations.eventId, eventId), eq(registrations.memberName, "admin")));
        if (registration) {
          await tx.delete(registrations).where(eq(registrations.id, registration.id));
          await tx.update(events).set({ attendees: Math.max(0, event.attendees - 1) }).where(eq(events.id, eventId));
          message = "Deine Anmeldung wurde zurückgenommen.";
        } else {
          await tx.insert(registrations).values({ id: id(), eventId, memberName: "admin" });
          await tx.update(events).set({ attendees: event.attendees + 1 }).where(eq(events.id, eventId));
          message = "Du bist dabei! Deine Anmeldung wurde gespeichert.";
        }
      });
    } else if (body.action === "create-announcement") {
      const title = text(p.title, "Der Titel", 180);
      await db.transaction(async (tx) => {
        await tx.insert(announcements).values({ id: id(), title, content: text(p.content, "Der Text", 10000) });
        await tx.insert(activities).values(log("Neuigkeiten aus dem Verein", title, "announcement"));
      });
      message = "Deine Ankündigung wurde veröffentlicht.";
    } else if (body.action === "save-settings") {
      const values = { clubName: text(p.clubName, "Der Vereinsname", 100), city: text(p.city, "Der Ort", 100), email: validEmail(p.email), adminName: text(p.adminName, "Dein Name", 100), training: text(p.training, "Die Trainingszeit", 150), notifications: p.notifications === true ? "true" : "false" };
      await db.transaction(async (tx) => {
        for (const [key, value] of Object.entries(values)) await tx.insert(settings).values({ key, value }).onConflictDoUpdate({ target: settings.key, set: { value } });
      });
      message = "Die Vereinseinstellungen wurden gespeichert.";
    } else if (body.action === "run-contributions") {
      const year = yearValue(p.year);
      const people = await db.select().from(members);
      let count = 0;
      await db.transaction(async (tx) => {
        if (people.length) {
          const inserted = await tx.insert(contributions).values(people.map((person) => ({ id: id(), memberId: person.id, year, totalCents: annualFees[person.category] ?? 9000, dueDate: `${year}-03-31` }))).onConflictDoNothing().returning();
          count = inserted.length;
        }
        if (count) await tx.insert(activities).values(log("Beitragslauf abgeschlossen", `${count} Jahresbeiträge für ${year} angelegt.`, "payment"));
      });
      message = count ? `${count} neue Beiträge für ${year} angelegt.` : `Alle Beiträge für ${year} sind bereits angelegt. Es wurden keine Duplikate erzeugt.`;
    } else if (body.action === "remind") {
      const contributionId = text(p.id, "Der Beitrag");
      await db.transaction(async (tx) => {
        const [due] = await tx.select().from(contributions).where(eq(contributions.id, contributionId)).for("update");
        if (!due || due.paidCents >= due.totalCents) throw new InputError("Für diesen Beitrag ist keine Erinnerung erforderlich.");
        await tx.update(contributions).set({ reminderLevel: Math.min(due.reminderLevel + 1, 2) }).where(eq(contributions.id, contributionId));
        await tx.insert(activities).values(log("Zahlungserinnerung vermerkt", `Mahnstufe für Beitrag ${due.year} aktualisiert.`, "payment"));
      });
      message = "Zahlungserinnerung vermerkt. Es wurde keine E-Mail versendet.";
    } else {
      throw new InputError("Diese Aktion ist nicht verfügbar.");
    }
    return NextResponse.json({ data: await getClubData(), message });
  } catch (error) {
    if (error instanceof InputError) return NextResponse.json({ error: error.message }, { status: 400 });
    console.error("Club mutation error", error);
    return NextResponse.json({ error: "Die Änderung konnte nicht gespeichert werden. Bitte versuche es erneut." }, { status: 500 });
  }
}
