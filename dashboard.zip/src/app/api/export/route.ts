import { getClubData } from "@/lib/data";

export const dynamic = "force-dynamic";
const csvCell = (value: unknown) => {
  let str = String(value ?? "");
  if (/^[=+@\-\t\r]/.test(str)) str = "'" + str;
  return '"' + str.replace(/"/g, '""') + '"';
};

export async function GET(request: Request) {
  try {
    const params = new URL(request.url).searchParams;
    const type = params.get("type") ?? "contributions";
    const year = Number(params.get("year") ?? 2026);
    if (!["contributions", "members", "payments"].includes(type) || !Number.isInteger(year) || year < 2020 || year > 2040) return Response.json({ error: "Ungültiger Export." }, { status: 400 });
    const data = await getClubData();
    let rows: unknown[][];
    let filename: string;
    if (type === "members") {
      filename = "Mitglieder";
      rows = [["Name", "E-Mail", "Telefon", "Adresse", "Kategorie", "Status", "Eintritt", "DWZ"], ...data.members.map((m) => [m.name, m.email, m.phone, m.address, m.category, m.status, m.joinedAt, m.rating])];
    } else if (type === "payments") {
      filename = `Zahlungen-${year}`;
      rows = [["Datum", "Mitglied", "Betrag EUR", "Zahlungsart"], ...data.payments.filter((p) => p.bookedAt.startsWith(String(year))).map((p) => [p.bookedAt.slice(0, 10), data.members.find((m) => m.id === p.memberId)?.name, (p.amountCents / 100).toFixed(2).replace(".", ","), p.method])];
    } else {
      filename = `Beitraege-${year}`;
      rows = [["Mitglied", "Kategorie", "Jahr", "Beitrag EUR", "Bezahlt EUR", "Offen EUR", "Mahnstufe"], ...data.contributions.filter((c) => c.year === year).map((c) => [c.member.name, c.member.category, c.year, (c.totalCents / 100).toFixed(2).replace(".", ","), (c.paidCents / 100).toFixed(2).replace(".", ","), ((c.totalCents - c.paidCents) / 100).toFixed(2).replace(".", ","), c.reminderLevel])];
    }
    return new Response("\uFEFF" + rows.map((row) => row.map(csvCell).join(";")).join("\r\n"), { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${filename}.csv"`, "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("CSV export error", error);
    return Response.json({ error: "Der Export konnte nicht erstellt werden." }, { status: 500 });
  }
}
