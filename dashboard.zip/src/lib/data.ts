import { db } from "@/db";
import { activities, announcements, contributions, events, members, payments, registrations, requests, settings } from "@/db/schema";
import { asc, desc, eq, sql } from "drizzle-orm";
import { annualFees } from "@/lib/utils";
import type { ClubData, Member } from "@/lib/types";

let seedPromise: Promise<void> | undefined;

export function ensureSeeded() {
  if (!seedPromise) seedPromise = seedClub().catch((error) => { seedPromise = undefined; throw error; });
  return seedPromise;
}

async function seedClub() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(82736491)`);
    const existing = await tx.select().from(settings).where(eq(settings.key, "seeded")).limit(1);
    if (existing.length) return;

    const names = ["Katrin Becker", "Diana Bergmann", "Nico Brandt", "Hanna Fischer", "Andreas Frank", "Tanja Graf", "Lukas Hartmann", "Marie Hoffmann", "Felix Jäger", "Sabine Keller", "Thomas Krüger", "Lena Fischer", "Anna Albrecht", "Jonas Lehmann", "Emma Lorenz", "Max Möller", "Laura Otto", "Leon Peters", "Mia Richter", "Ben Schäfer", "Sophie Schulz", "Emil Schuster", "Clara Sommer", "Anton Vogel", "Luisa Wagner", "Finn Wolf", "Markus Weber", "Sebastian Braun", "Julia Dietrich", "Michael Fuchs", "Sarah Günther", "Alexander Hofmann", "Katharina Jung", "Tobias Koch", "Christian Lange", "Elisabeth Meyer", "Daniel Neumann", "Petra Schröder", "Paul Neumann", "Julian Zimmermann", "Familie Schmitt", "Familie Wolff", "Helga Winter", "Jan König"];
    const categoryList = ["Erwachsene", "Jugendliche", "Familie", "Ermäßigt", "Jugendliche", "Erwachsene", ...Array.from({ length: 30 }, (_, i) => i % 2 === 0 ? "Erwachsene" : "Jugendliche"), "Erwachsene", "Erwachsene", "Erwachsene", "Erwachsene", "Jugendliche", "Familie", "Familie", "Ermäßigt"];
    const colors = ["sage", "lavender", "sand", "rose", "blue", "peach"];
    const people: Member[] = names.map((name, i) => ({
      id: `member-${i + 1}`, name,
      email: `${name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, ".")}@example.de`,
      phone: `0151 ${String(24580100 + i)}`,
      address: `Marktstraße ${i + 1}, 12345 Musterstadt`,
      category: categoryList[i], status: i >= 40 ? "Passiv" : "Aktiv",
      joinedAt: i === 38 ? "2026-09-29" : i > 36 && i < 40 ? "2026-02-15" : `202${i % 5}-${String((i % 9) + 1).padStart(2, "0")}-15`,
      rating: categoryList[i] === "Jugendliche" ? 950 + i * 17 : 1400 + (i * 29) % 700,
      color: colors[i % colors.length],
    }));
    people[11].email = "lena.fischer@web.de";
    people[12].address = "Parkweg 3, 12345 Musterstadt";
    await tx.insert(members).values(people).onConflictDoNothing();
    const dues = people.map((person, i) => ({
      id: `contribution-${i + 1}`, memberId: person.id, year: 2026,
      totalCents: annualFees[person.category],
      paidCents: i >= 26 ? annualFees[person.category] : i === 0 ? 4500 : i === 1 ? 2250 : i === 6 ? 4750 : 0,
      reminderLevel: i === 2 ? 2 : i === 5 ? 1 : 0,
      dueDate: "2026-03-31",
    }));
    await tx.insert(contributions).values(dues).onConflictDoNothing();
    const september = [26, 28, 30, 27, 29, 43];
    await tx.insert(payments).values(dues.flatMap((due, i) => due.paidCents > 0 ? [{
      id: `payment-${i + 1}`, contributionId: due.id, memberId: due.memberId, amountCents: due.paidCents,
      method: "Überweisung", bookedAt: september.includes(i) ? `2026-09-${String(12 + september.indexOf(i) * 3).padStart(2, "0")}T10:00:00Z` : `2026-0${(i % 7) + 2}-15T10:00:00Z`,
    }] : [])).onConflictDoNothing();
    await tx.insert(events).values([
      { id: "event-club", title: "Offener Vereinsabend", type: "Vereinsabend", date: "2026-10-02", time: "19:00", location: "Vereinsheim · Marktstraße 12", status: "Offen für alle", description: "Eine gute Partie, nette Menschen und Zeit zum gemeinsamen Analysieren. Ob langjähriges Mitglied oder zum ersten Mal dabei: Bei unserem offenen Vereinsabend ist jeder willkommen. Bretter und Uhren stehen bereit – bring einfach Lust auf Schach mit.", attendees: 12 },
      { id: "event-1", title: "1. Mannschaft – SC Turmbau", type: "Mannschaft", date: "2026-10-13", time: "14:00", location: "Vereinsheim", status: "Aufstellung steht", team: "1. Mannschaft", description: "5. Runde der Bezirksliga. Wir spielen zu Hause gegen den SC Turmbau. Bitte 30 Minuten vor Spielbeginn vor Ort sein. Zuschauer sind herzlich willkommen.", attendees: 8 },
      { id: "event-2", title: "Rapidturnier am Vereinsabend", type: "Turnier", date: "2026-10-20", time: "19:00", location: "Vereinsheim", status: "Anmeldung offen", description: "Unser monatliches Schnellschachturnier: 5 Runden Schweizer System, 15 Minuten + 10 Sekunden pro Zug. Die Teilnahme ist für Mitglieder kostenlos. Anmeldeschluss ist um 18:45 Uhr vor Ort.", attendees: 9 },
      { id: "event-3", title: "2. Mannschaft bei SC Rochade Süd", type: "Mannschaft", date: "2026-10-27", time: "18:30", location: "Schachzentrum Süd", status: "Geplant", team: "2. Mannschaft", description: "6. Runde der Kreisliga. Treffpunkt zur gemeinsamen Abfahrt ist um 17:30 Uhr am Vereinsheim. Bitte meldet euch für die Fahrgemeinschaft an.", attendees: 6 },
      { id: "event-4", title: "Jugend U16 – Brettbrecher Göttingen", type: "Mannschaft", date: "2026-11-03", time: "14:00", location: "Vereinsheim", status: "Geplant", team: "Jugend U16", description: "Unser Jugendteam empfängt die Brettbrecher aus Göttingen. Eltern und Freunde dürfen gerne zum Anfeuern vorbeikommen.", attendees: 6 },
      { id: "event-5", title: "Jugendpokal 2027", type: "Turnier", date: "2027-03-14", time: "10:00", location: "Bürgerhaus Musterstadt", status: "Entwurf", description: "Unser jährlicher Jugendpokal für alle Nachwuchsspielerinnen und Nachwuchsspieler. Die Ausschreibung folgt rechtzeitig.", attendees: 0 },
    ]).onConflictDoNothing();
    await tx.insert(requests).values([
      { id: "request-1", memberId: "member-12", field: "email", oldValue: "lena.fischer@web.de", newValue: "lena.fischer@mail.de", status: "Offen", createdAt: "2026-09-30T09:30:00Z" },
      { id: "request-2", memberId: "member-13", field: "address", oldValue: "Parkweg 3, 12345 Musterstadt", newValue: "Gartenstraße 14, 12345 Musterstadt", status: "Offen", createdAt: "2026-09-30T08:15:00Z" },
      { id: "request-3", memberId: "member-12", field: "phone", oldValue: "0151 24580111", newValue: "0176 23456789", status: "Offen", createdAt: "2026-09-29T16:00:00Z" },
    ]).onConflictDoNothing();
    await tx.insert(activities).values([
      { id: "activity-1", title: "Ein neues Gesicht im Verein", description: "Paul Neumann ist jetzt Mitglied.", type: "member", createdAt: "2026-09-30T10:42:00Z" },
      { id: "activity-2", title: "Beitrag eingegangen", description: "Markus Weber · 90,00 € gebucht", type: "payment", createdAt: "2026-09-30T09:15:00Z" },
      { id: "activity-3", title: "Bereit für den nächsten Spieltag", description: "Aufstellung der 1. Mannschaft gemeldet.", type: "event", createdAt: "2026-09-29T18:30:00Z" },
      { id: "activity-4", title: "Herbstturnier angekündigt", description: "Eine neue Ankündigung wurde veröffentlicht.", type: "announcement", createdAt: "2026-09-29T15:00:00Z" },
    ]).onConflictDoNothing();
    await tx.insert(announcements).values({ id: "announcement-1", title: "Der Herbst wird schachlich!", content: "Liebe Schachfreundinnen und Schachfreunde,\n\nam 20. Oktober findet unser nächstes Rapidturnier statt. Gespielt werden fünf Runden mit 15 Minuten Bedenkzeit plus 10 Sekunden pro Zug. Egal ob Turnierprofi oder Neuling – alle sind herzlich eingeladen!\n\nMeldet euch einfach über den Kalender an. Wir freuen uns auf spannende Partien und einen schönen gemeinsamen Abend.\n\nEuer Vorstand", createdAt: "2026-09-29T15:00:00Z" }).onConflictDoNothing();
    await tx.insert(settings).values([
      { key: "seeded", value: "1" }, { key: "clubName", value: "SC Königsspringer" },
      { key: "city", value: "Musterstadt" }, { key: "email", value: "vorstand@sc-koenigsspringer.de" },
      { key: "adminName", value: "Andreas Bauer" }, { key: "training", value: "Freitags ab 19:00 Uhr" },
      { key: "donations2026", value: "76450" }, { key: "expenses2026", value: "92750" },
      { key: "notifications", value: "true" },
    ]).onConflictDoNothing();
  });
}

export async function getClubData(): Promise<ClubData> {
  await ensureSeeded();
  const [people, dues, paymentList, eventList, requestList, activityList, announcementList, registrationList, settingList] = await Promise.all([
    db.select().from(members).orderBy(asc(members.name)),
    db.select().from(contributions),
    db.select().from(payments).orderBy(desc(payments.bookedAt)),
    db.select().from(events).orderBy(asc(events.date), asc(events.time)),
    db.select().from(requests).orderBy(desc(requests.createdAt)),
    db.select().from(activities).orderBy(desc(activities.createdAt)).limit(100),
    db.select().from(announcements).orderBy(desc(announcements.createdAt)),
    db.select().from(registrations).where(eq(registrations.memberName, "admin")),
    db.select().from(settings),
  ]);
  const byId = new Map(people.map((person) => [person.id, person]));
  return {
    members: people,
    contributions: dues.sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true })).map((due) => ({ ...due, member: byId.get(due.memberId)! })),
    payments: paymentList,
    events: eventList,
    requests: requestList.map((request) => ({ ...request, member: byId.get(request.memberId)! })),
    activities: activityList,
    announcements: announcementList,
    registrations: registrationList.map((registration) => registration.eventId),
    settings: Object.fromEntries(settingList.map((setting) => [setting.key, setting.value])),
  };
}
