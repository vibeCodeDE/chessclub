export const categories = ["Erwachsene", "Jugendliche", "Familie", "Ermäßigt"] as const;
export const annualFees: Record<string, number> = { Erwachsene: 9000, Jugendliche: 4500, Familie: 13000, Ermäßigt: 6000 };
export const euro = (cents: number) => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(cents / 100);
export const initials = (name: string) => name.split(" ").map((part) => part[0]).slice(0, 2).join("");
export const shortDate = (date: string) => new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(date));
export const eventDate = (date: string) => new Intl.DateTimeFormat("de-DE", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date(date + "T12:00:00"));
export const monthShort = (date: string) => new Intl.DateTimeFormat("de-DE", { month: "short" }).format(new Date(date + "T12:00:00")).replace(".", "").toUpperCase();
export const activityTime = (date: string) => {
  const elapsed = Date.now() - new Date(date).getTime();
  if (elapsed >= 0 && elapsed < 60000) return "Gerade eben";
  if (elapsed >= 0 && elapsed < 3600000) return `Vor ${Math.floor(elapsed / 60000)} Min.`;
  if (date.startsWith("2026-09-30")) return "Heute";
  if (date.startsWith("2026-09-29")) return "Gestern";
  return shortDate(date);
};
