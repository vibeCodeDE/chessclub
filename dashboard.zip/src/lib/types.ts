import type { members, contributions, payments, events, requests, activities, announcements } from "@/db/schema";

export type Member = typeof members.$inferSelect;
export type Contribution = typeof contributions.$inferSelect & { member: Member };
export type Payment = typeof payments.$inferSelect;
export type ClubEvent = typeof events.$inferSelect;
export type ChangeRequest = typeof requests.$inferSelect & { member: Member };
export type Activity = typeof activities.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;

export type ClubData = {
  members: Member[];
  contributions: Contribution[];
  payments: Payment[];
  events: ClubEvent[];
  requests: ChangeRequest[];
  activities: Activity[];
  announcements: Announcement[];
  registrations: string[];
  settings: Record<string, string>;
};

export type View = "overview" | "members" | "finance" | "games" | "calendar" | "announcements" | "requests" | "club" | "activity";
export type ModalState =
  | { type: "member"; member?: Member }
  | { type: "payment"; contribution: Contribution }
  | { type: "request"; request: ChangeRequest }
  | { type: "event"; event: ClubEvent }
  | { type: "new-event"; date?: string }
  | { type: "announcement"; announcement?: Announcement }
  | { type: "settings" }
  | { type: "help" }
  | { type: "contribution-run" }
  | null;
