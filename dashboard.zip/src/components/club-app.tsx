"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Bell, CalendarDays, Check, ChevronDown, ChevronRight, ChevronsUpDown, CircleHelp, CreditCard, Download, Globe2, LayoutDashboard, Mail, Megaphone, Menu, Plus, Search, Settings2, ShieldCheck, Trophy, UserPlus, Users, X } from "lucide-react";
import type { ClubData, ModalState, View } from "@/lib/types";
import { Avatar } from "@/components/ui";
import { Knight } from "@/components/knight";
import { Overview } from "@/components/overview";
import { WorkspaceView } from "@/components/workspace-views";
import { ClubModal } from "@/components/club-modal";

const navigation = [
  { id: "overview" as View, label: "Übersicht", icon: LayoutDashboard },
  { id: "members" as View, label: "Mitglieder", icon: Users },
  { id: "finance" as View, label: "Beiträge & Kasse", icon: CreditCard },
  { id: "games" as View, label: "Spielbetrieb", icon: Trophy },
  { id: "calendar" as View, label: "Kalender", icon: CalendarDays },
];
const organization = [
  { id: "announcements" as View, label: "Ankündigungen", icon: Megaphone },
  { id: "requests" as View, label: "Änderungswünsche", icon: ShieldCheck },
  { id: "club" as View, label: "Vereinsseite", icon: Globe2 },
];
const titles: Record<View, string> = { overview: "Übersicht", members: "Mitglieder", finance: "Beiträge & Kasse", games: "Spielbetrieb", calendar: "Kalender", announcements: "Ankündigungen", requests: "Änderungswünsche", club: "Vereinsseite", activity: "Vereinsaktivität" };
const descriptions: Record<View, string> = { overview: "Dein Verein im Überblick. Schön, dass du da bist.", members: "Die Menschen, die deinen Verein ausmachen.", finance: "Klare Zahlen. Ein gutes Gefühl für die Vereinskasse.", games: "Mannschaften, Turniere und der nächste gute Zug.", calendar: "Gemeinsame Zeit beginnt mit einem guten Plan.", announcements: "Alles, was deine Mitglieder wissen sollten.", requests: "Aktuelle Daten – mit einem kurzen Blick von dir.", club: "Ein Verein. Viele gute Züge. Noch mehr Gemeinschaft.", activity: "Was sich in deinem Verein bewegt hat." };

export function ClubApp({ initialData, initialView }: { initialData: ClubData; initialView: View }) {
  const [data, setData] = useState(initialData);
  const [view, setView] = useState<View>(initialView);
  const [year, setYear] = useState(2026);
  const [modal, setModal] = useState<ModalState>(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [newMenu, setNewMenu] = useState(false);
  const [notifications, setNotifications] = useState(false);
  const [notificationRead, setNotificationRead] = useState(false);
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const searchRef = useRef<HTMLInputElement>(null);
  const searchArea = useRef<HTMLDivElement>(null);
  const pending = data.requests.filter((r) => r.status === "Offen");

  const navigate = (next: View) => {
    setView(next); setMobileNav(false); setSearch(""); setNotifications(false); setNewMenu(false);
    window.history.pushState({}, "", next === "overview" ? "/" : `/?view=${next}`);
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const openModal = (next: ModalState) => { setError(""); setModal(next); setNewMenu(false); setSearch(""); setNotifications(false); };

  useEffect(() => {
    document.title = `${titles[view]} · Schachclubmanager`;
  }, [view]);
  useEffect(() => {
    const onPop = () => { const next = new URLSearchParams(window.location.search).get("view") as View; setView(next && next in titles ? next : "overview"); };
    const onKey = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") { event.preventDefault(); searchRef.current?.focus(); }
      if (event.key === "Escape") { setNewMenu(false); setSearch(""); setNotifications(false); setMobileNav(false); }
    };
    const onClick = (event: MouseEvent) => { if (searchArea.current && !searchArea.current.contains(event.target as Node)) setSearch(""); };
    window.addEventListener("popstate", onPop); window.addEventListener("keydown", onKey); document.addEventListener("mousedown", onClick);
    return () => { window.removeEventListener("popstate", onPop); window.removeEventListener("keydown", onKey); document.removeEventListener("mousedown", onClick); };
  }, []);
  useEffect(() => { if (toast) { const timer = setTimeout(() => setToast(""), 5500); return () => clearTimeout(timer); } }, [toast]);

  async function mutate(action: string, payload: Record<string, unknown>) {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/club", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, payload }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Die Änderung konnte nicht gespeichert werden.");
      setData(result.data); setToast(result.message); return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Bitte prüfe deine Verbindung und versuche es erneut."); return false;
    } finally { setBusy(false); }
  }

  const query = search.trim().toLocaleLowerCase("de");
  const foundMembers = query ? data.members.filter((m) => `${m.name} ${m.email}`.toLocaleLowerCase("de").includes(query)).slice(0, 4) : [];
  const foundEvents = query ? data.events.filter((event) => `${event.title} ${event.type}`.toLocaleLowerCase("de").includes(query)).slice(0, 3) : [];
  const foundPages = query ? [...navigation, ...organization].filter((item) => item.label.toLocaleLowerCase("de").includes(query)).slice(0, 3) : [];

  const navItem = (item: typeof navigation[number]) => <button key={item.id} className={`nav-item ${view === item.id ? "active" : ""}`} onClick={() => navigate(item.id)} aria-current={view === item.id ? "page" : undefined}><item.icon size={18} strokeWidth={1.7} /><span>{item.label}</span>{item.id === "members" && <span className="nav-number">{data.members.length}</span>}{item.id === "requests" && pending.length > 0 && <span className="nav-badge">{pending.length}</span>}{item.id === "announcements" && data.announcements.length > 0 && <span className="nav-dot" />}{item.id === "club" && <ArrowUpRight size={14} className="nav-external" />}</button>;

  return <div className="app-shell">
    {mobileNav && <button className="mobile-nav-backdrop" onClick={() => setMobileNav(false)} aria-label="Navigation schließen" />}
    <aside className={`sidebar ${mobileNav ? "is-open" : ""}`}>
      <Link className="brand" href="/" onClick={(event) => { event.preventDefault(); navigate("overview"); }}><span className="brand-mark"><Knight size={28} /></span><span>schachclub<span className="brand-second">manager<span className="brand-period">.</span></span></span></Link>
      <button className="club-switcher" onClick={() => openModal({ type: "settings" })}><span className="club-emblem"><Knight size={21} /></span><span><strong>{data.settings.clubName}</strong><small>{data.settings.city} · Dein Verein</small></span><ChevronsUpDown size={14} /></button>
      <nav className="main-navigation" aria-label="Hauptnavigation"><p className="nav-label">VEREINSVERWALTUNG</p><div className="nav-group">{navigation.map(navItem)}</div><p className="nav-label organization-label">ORGANISATION</p><div className="nav-group">{organization.map(navItem)}</div></nav>
      <div className="sidebar-bottom"><div className="sidebar-tip"><span className="tip-decor"><Knight size={48} /></span><strong>Mehr Zeit<br />fürs Schach.</strong><p>Weniger Verwaltung.<br />Mehr Vereinsleben.</p><span className="tip-line" /></div><div className="utility-nav"><button onClick={() => openModal({ type: "settings" })}><Settings2 size={17} strokeWidth={1.6} />Einstellungen</button><button onClick={() => openModal({ type: "help" })}><CircleHelp size={17} strokeWidth={1.6} />Hilfe & Support<ArrowUpRight size={13} /></button></div><button className="sidebar-profile" onClick={() => openModal({ type: "settings" })}><Avatar name={data.settings.adminName} color="sage" /><span><strong>{data.settings.adminName}</strong><small>Vorstand · Administrator</small></span><ChevronDown size={15} /></button></div>
      <button className="mobile-nav-close icon-button" onClick={() => setMobileNav(false)} aria-label="Navigation schließen"><X size={20} /></button>
    </aside>
    <div className="main-shell">
      <header className="topbar"><div className="breadcrumb"><button className="mobile-menu icon-button" aria-label="Navigation öffnen" onClick={() => setMobileNav(true)}><Menu size={21} /></button><span>Vereinsverwaltung</span><ChevronRight size={13} /><strong>{titles[view]}</strong></div><div className="topbar-actions"><div className="global-search" ref={searchArea}><Search size={16} /><input ref={searchRef} placeholder="Verein durchsuchen …" aria-label="Verein durchsuchen" value={search} onChange={(event) => setSearch(event.target.value)} /><kbd>⌘ K</kbd>{query && <div className="search-results"><div className="search-results-label">SUCHERGEBNISSE</div>{foundPages.map((item) => <button key={item.id} onClick={() => navigate(item.id)}><item.icon size={18} /><span>{item.label}<small>Bereich öffnen</small></span><ArrowUpRight size={14} /></button>)}{foundMembers.map((member) => <button key={member.id} onClick={() => openModal({ type: "member", member })}><Avatar name={member.name} color={member.color} size="sm" /><span>{member.name}<small>Mitglied · {member.category}</small></span><ChevronRight size={14} /></button>)}{foundEvents.map((event) => <button key={event.id} onClick={() => openModal({ type: "event", event })}><CalendarDays size={18} /><span>{event.title}<small>{event.date.split("-").reverse().join(".")}</small></span><ChevronRight size={14} /></button>)}{!foundMembers.length && !foundEvents.length && !foundPages.length && <p className="search-empty">Keine Ergebnisse für „{search}“.<br /><small>Versuche einen Namen, Termin oder Bereich.</small></p>}<div className="search-tip">Mit Esc schließen</div></div>}</div><span className="topbar-separator" /><div className="notification-anchor"><button className={`icon-button notification-button ${notifications ? "selected" : ""}`} onClick={() => { setNotifications(!notifications); setNewMenu(false); }} aria-label="Benachrichtigungen" aria-expanded={notifications}><Bell size={19} strokeWidth={1.6} />{!notificationRead && data.settings.notifications !== "false" && <span />}</button>{notifications && <div className="notification-menu"><div className="dropdown-heading"><strong>Benachrichtigungen</strong><button className="icon-button small" title="Als gelesen markieren" aria-label="Alle Benachrichtigungen als gelesen markieren" onClick={() => { setNotificationRead(true); setToast("Alle Benachrichtigungen als gelesen markiert."); }}><Check size={17} /></button></div>{pending.length > 0 && <button onClick={() => navigate("requests")}><span className="notification-symbol"><ShieldCheck size={18} /></span><span><strong>{pending.length} Anfragen warten auf dich</strong><small>Prüfe die neuen Mitgliedsdaten.</small></span><ChevronRight size={14} /></button>}{data.announcements.slice(0, 1).map((announcement) => <button key={announcement.id} onClick={() => openModal({ type: "announcement", announcement })}><span className="notification-symbol"><Megaphone size={18} /></span><span><strong>{announcement.title}</strong><small>Neuigkeiten für deinen Verein</small></span><ChevronRight size={14} /></button>)}{!pending.length && !data.announcements.length && <p className="search-empty">Du bist auf dem neuesten Stand.</p>}</div>}</div><button className="topbar-avatar" onClick={() => openModal({ type: "settings" })} aria-label="Mein Profil"><Avatar name={data.settings.adminName} color="sand" size="sm" /></button></div></header>
      <main className="main-content"><div className="page-heading"><div><div className="page-eyebrow">{view === "overview" ? "MITTWOCH, 30. SEPTEMBER 2026" : data.settings.clubName.toUpperCase()}</div><h1>{view === "overview" ? `Guten Tag, ${data.settings.adminName.split(" ")[0]}.` : titles[view]}</h1><p>{descriptions[view]}</p></div><div className="page-heading-actions"><a href={`/api/export?type=${view === "members" ? "members" : "contributions"}&year=${year}`} className="button button-secondary export-button" download><Download size={15} />Exportieren</a><div className={`new-menu-anchor ${newMenu ? "menu-open" : ""}`}><button className="button button-primary" onClick={() => { setNewMenu(!newMenu); setNotifications(false); }} aria-expanded={newMenu}><Plus size={17} />Neu anlegen<ChevronDown size={13} /></button>{newMenu && <div className="new-menu"><button onClick={() => openModal({ type: "member" })}><UserPlus size={18} /><span>Mitglied hinzufügen<small>Ein neues Gesicht im Verein</small></span></button><button onClick={() => openModal({ type: "new-event" })}><CalendarDays size={18} /><span>Termin erstellen<small>Gemeinsame Zeit planen</small></span></button><button onClick={() => openModal({ type: "announcement" })}><Megaphone size={18} /><span>Ankündigung schreiben<small>Neuigkeiten mit allen teilen</small></span></button></div>}</div></div></div>
        {view === "overview" ? <Overview data={data} year={year} onNavigate={navigate} onModal={openModal} /> : <WorkspaceView key={view} view={view} data={data} year={year} setYear={setYear} onModal={openModal} onNavigate={navigate} />}
      </main>
    </div>
    {(newMenu || notifications) && <button className={`dropdown-backdrop ${notifications ? "for-notifications" : ""}`} onClick={() => { setNewMenu(false); setNotifications(false); }} aria-label="Menü schließen" />}
    {modal && <ClubModal modal={modal} data={data} year={year} busy={busy} error={error} onClose={() => { if (!busy) setModal(null); }} onMutate={mutate} />}
    {toast && <div className="toast" role="status"><span><Check size={16} /></span><p>{toast}</p><button onClick={() => setToast("")} aria-label="Meldung schließen"><X size={16} /></button></div>}
  </div>;
}
