"use client";

import { useState } from "react";
import Image from "next/image";
import { ArrowDownLeft, ArrowRight, ArrowUpRight, CheckCheck, ChevronRight, CircleHelp, Clock3, CreditCard, Mail, MapPin, Phone, Trophy, UserPlus, Users, Wallet, Banknote, Sparkle } from "lucide-react";
import type { ClubData, ModalState, View } from "@/lib/types";
import { activityTime, euro } from "@/lib/utils";
import { Avatar, Badge, ContributionTable, EmptyState, EventRow } from "@/components/ui";

type Props = { data: ClubData; year: number; onNavigate: (view: View) => void; onModal: (modal: ModalState) => void };

export function Stats({ data, year }: Pick<Props, "data" | "year">) {
  const dues = data.contributions.filter((c) => c.year === year);
  const total = dues.reduce((sum, c) => sum + c.totalCents, 0);
  const paid = dues.reduce((sum, c) => sum + c.paidCents, 0);
  const outstanding = dues.filter((c) => c.paidCents < c.totalCents);
  const income = paid + Number(data.settings[`donations${year}`] ?? 0);
  const expenses = Number(data.settings[`expenses${year}`] ?? 0);
  const monthlyPayments = data.payments.filter((p) => p.bookedAt.startsWith(`${year}-09`));
  const monthly = Array.from({ length: 6 }, (_, i) => data.payments.filter((p) => p.bookedAt.startsWith(`${year}-${String(i + 4).padStart(2, "0")}`)).reduce((sum, p) => sum + p.amountCents, 0));
  const max = Math.max(...monthly, 1);
  const recent = data.members.filter((m) => m.joinedAt.startsWith(String(year))).length;
  return <div className="stats-grid">
    <section className="stat-card"><div className="stat-label">Mitglieder<Users size={17} /></div><div className="stat-value">{data.members.length}<span className="stat-growth"><ArrowUpRight size={12} />{recent} dieses Jahr</span></div><div className="stat-bottom"><span>{data.members.filter((m) => m.status === "Aktiv").length} aktiv <span className="middle-dot">·</span> {data.members.filter((m) => m.status === "Passiv").length} passiv</span><span className="avatar-stack">{data.members.slice(4, 7).map((m) => <Avatar key={m.id} name={m.name} color={m.color} size="sm" />)}<span className="stack-more">+{Math.max(0, data.members.length - 3)}</span></span></div></section>
    <section className="stat-card"><div className="stat-label">Offene Beiträge<CreditCard size={17} /></div><div className="stat-value money-value">{euro(total - paid)}</div><div className="stat-bottom"><span><span className="status-dot amber" />{outstanding.length} von {dues.length} Beiträgen offen</span><span className="progress-percent">{total ? Math.round(paid / total * 100) : 0} %</span></div><div className="progress-track"><span style={{ width: `${total ? paid / total * 100 : 0}%` }} /></div></section>
    <section className="stat-card"><div className="stat-label">Vereinskasse<Wallet size={17} /></div><div className="stat-value money-value">{euro(income - expenses)}</div><div className="cash-meta"><span><ArrowDownLeft size={13} />{euro(income)} <small>ein</small></span><span><ArrowUpRight size={13} />{euro(expenses)} <small>aus</small></span></div></section>
    <section className="stat-card monthly-stat"><div className="stat-label">Zahlungen im September<Banknote size={17} /></div><div className="stat-value money-value">{euro(monthlyPayments.reduce((sum, p) => sum + p.amountCents, 0))}</div><div className="stat-bottom"><span>{monthlyPayments.length} Buchungen</span></div><div className="mini-chart" aria-label="Zahlungen April bis September">{monthly.map((amount, i) => <div key={i} title={`${["April", "Mai", "Juni", "Juli", "August", "September"][i]}: ${euro(amount)}`} className={i === 5 ? "current" : ""} style={{ height: `${Math.max(8, amount / max * 39)}px` }} />)}</div></section>
  </div>;
}

export function Overview({ data, year, onNavigate, onModal }: Props) {
  const [eventFilter, setEventFilter] = useState("Alle Termine");
  const outstanding = data.contributions.filter((c) => c.year === year && c.paidCents < c.totalCents);
  const pending = data.requests.filter((r) => r.status === "Offen");
  const upcoming = data.events.filter((event) => event.type !== "Vereinsabend" && event.status !== "Entwurf" && (eventFilter === "Alle Termine" || event.type === (eventFilter === "Mannschaften" ? "Mannschaft" : "Turnier"))).slice(0, 3);
  const clubEvening = data.events.find((event) => event.type === "Vereinsabend");
  return <>
    <Stats data={data} year={year} />
    <div className="dashboard-columns"><div className="dashboard-main-column">
      <section className="panel dues-panel"><div className="panel-heading"><div><h2>Offene Beiträge <span className="count-badge">{outstanding.length}</span></h2><p>Ein Überblick über ausstehende Zahlungen.</p></div><button className="text-button" onClick={() => onNavigate("finance")}>Alle ansehen <ArrowUpRight size={15} /></button></div><ContributionTable items={outstanding.slice(0, 5)} onPayment={(contribution) => onModal({ type: "payment", contribution })} onMember={(member) => onModal({ type: "member", member })} compact /><div className="panel-footer"><span><span className="status-dot amber" />{euro(outstanding.reduce((sum, c) => sum + c.totalCents - c.paidCents, 0))} insgesamt offen</span><button onClick={() => onModal({ type: "contribution-run" })}>Beiträge verwalten <ArrowRight size={14} /></button></div></section>
      <section className="panel events-panel"><div className="panel-heading"><div><h2>Nächste Termine</h2><p>Was im Verein als Nächstes ansteht.</p></div><button className="text-button" onClick={() => onNavigate("calendar")}>Zum Kalender <ArrowUpRight size={15} /></button></div><div className="tab-strip">{["Alle Termine", "Mannschaften", "Turniere"].map((tab) => <button className={eventFilter === tab ? "active" : ""} key={tab} onClick={() => setEventFilter(tab)}>{tab}</button>)}</div><div className="event-list">{upcoming.map((event) => <EventRow key={event.id} event={event} onClick={() => onModal({ type: "event", event })} />)}{!upcoming.length && <EmptyState title="Noch keine Termine" description="Neue Termine erscheinen hier, sobald du sie anlegst." />}</div></section>
      <div className="dashboard-note"><CheckCheck size={15} /><span>Alles an einem Ort. Damit der nächste Zug wieder am Brett stattfindet.</span></div>
    </div><aside className="dashboard-side-column">
      <section className="panel tasks-panel"><div className="panel-heading"><div><h2>Deine Aufgaben <span className="count-badge amber-count">{pending.length}</span></h2><p>Ein kurzer Blick von dir genügt.</p></div></div><div className="task-list">{pending.slice(0, 3).map((request) => {
        const Icon = request.field === "email" ? Mail : request.field === "address" ? MapPin : Phone;
        return <button className="task-row" key={request.id} onClick={() => onModal({ type: "request", request })}><span className={`task-icon ${request.field}`}><Icon size={17} strokeWidth={1.7} /></span><span><strong>{request.field === "email" ? "E-Mail-Adresse ändern" : request.field === "address" ? "Neue Anschrift prüfen" : "Telefonnummer ändern"}</strong><small>{request.member.name} <span>·</span> {request.createdAt.startsWith("2026-09-30") ? "Heute" : "Gestern"}</small></span><ChevronRight size={16} /></button>;
      })}{!pending.length && <div className="tasks-done"><CheckCheck size={22} /><strong>Alles auf dem neuesten Stand.</strong><span>Du hast alle Anfragen erledigt.</span></div>}</div><button className="full-panel-link" onClick={() => onNavigate("requests")}>Alle Anfragen ansehen <ArrowRight size={14} /></button></section>
      {clubEvening && <button className="club-evening-card" onClick={() => onModal({ type: "event", event: clubEvening })}><Image src="/images/chess-evening.jpg" alt="Holzschachfiguren auf einem Schachbrett" fill sizes="(max-width: 640px) 100vw, (max-width: 1080px) 50vw, 32vw" priority /><span className="photo-shade" /><span className="evening-content"><span className="evening-eyebrow"><span />UNSER VEREINSABEND</span><strong>Gute Züge.<br />Gute Gesellschaft.</strong><span className="evening-date"><Clock3 size={13} />Freitag, 2. Oktober · 19:00 Uhr</span><span className="evening-link">Dabei sein <ArrowUpRight size={17} /></span></span></button>}
      <section className="panel activity-panel"><div className="panel-heading"><h2>Zuletzt im Verein</h2><button className="icon-button small" onClick={() => onNavigate("activity")} title="Alle Aktivitäten" aria-label="Alle Aktivitäten"><ArrowUpRight size={17} /></button></div><div className="activity-list">{data.activities.slice(0, 3).map((activity) => {
        const Icon = activity.type === "member" ? UserPlus : activity.type === "payment" ? CreditCard : Trophy;
        return <div className="activity-item" key={activity.id}><span className={`activity-symbol ${activity.type}`}><Icon size={14} /></span><div><strong>{activity.title}</strong><p>{activity.description}</p><small>{activityTime(activity.createdAt)}</small></div></div>;
      })}</div></section>
    </aside></div>
    <footer className="page-footer"><span>Mit Köpfchen verwalten. Mit Freude spielen.</span><span>Schachclubmanager <span className="footer-dot">·</span> <button onClick={() => onModal({ type: "help" })}>Hilfe & Feedback <CircleHelp size={12} /></button></span></footer>
  </>;
}
