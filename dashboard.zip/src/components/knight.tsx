export function Knight({ className = "", size = 30 }: { className?: string; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 32 36" fill="none" className={className} aria-hidden="true"><path d="M9 3 13 7l8 1 5 7-1 8-4 6H8l2-8 6-7-5 2-5-2 1-4 4-3-2-4Z" fill="currentColor"/><path d="m15 6 2-4 3 6" fill="currentColor"/><path d="M8 30h15l2 4H6l2-4Z" fill="currentColor"/><circle cx="16" cy="11" r="1" fill="var(--knight-eye, #f1f3ed)"/><path d="m10 22 7-7" stroke="var(--knight-eye, #f1f3ed)" strokeWidth="1.1" strokeLinecap="round"/></svg>;
}
