"use client";

import { ArrowUpRight, Check, CheckCircle2, ChevronRight, Clock3, MapPin } from "lucide-react";
import type { ReactNode } from "react";
import type { ClubEvent, Contribution, Member } from "@/lib/types";
import { euro, initials, monthShort } from "@/lib/utils";

export function Avatar({ name, color = "sage", size = "md" }: { name: string; color?: string; size?: "sm" | "md" | "lg" }) {
  return <span className={`avatar avatar-${color} avatar-${size}`} aria-hidden="true">{initials(name)}</span>;
}

export function Badge({ children, tone = "neutral", dot = false }: { children: ReactNode; tone?: "neutral" | "green" | "amber" | "blue" | "rose"; dot?: boolean }) {
  return <span className={`badge badge-${tone}`}>{dot && <span className="badge-dot" />}{children}</span>;
}

export function EmptyState({ title = "Alles erledigt!", description = "Hier gibt es gerade nichts zu tun.", children }: { title?: string; description?: string; children?: ReactNode }) {
  return <div className="empty-state"><span className="empty-icon"><CheckCircle2 size={24} strokeWidth={1.5} /></span><h3>{title}</h3><p>{description}</p>{children}</div>;
}

export function ContributionTable({ items, onPayment, onMember, compact = false }: { items: Contribution[]; onPayment: (item: Contribution) => void; onMember: (member: Member) => void; compact?: boolean }) {
  return <div className="table-scroll"><table className={`contribution-table ${compact ? "compact" : ""}`}><thead><tr><th>Mitglied</th><th className="amount">Beitrag</th><th className="amount">Offen</th><th>Status</th><th><span className="sr-only">Aktionen</span></th></tr></thead><tbody>{items.map((item) => {
    const remaining = item.totalCents - item.paidCents;
    return <tr key={item.id}><td><button className="person-cell" onClick={() => onMember(item.member)}><Avatar name={item.member.name} color={item.member.color} /><span><strong>{item.member.name}</strong><small>{item.member.category}</small></span></button></td><td className="amount muted">{euro(item.totalCents)}</td><td className={`amount ${remaining === 0 ? "muted" : "semibold"}`}>{euro(remaining)}</td><td>{remaining === 0 ? <Badge tone="green"><Check size={11} /> Bezahlt</Badge> : item.reminderLevel > 0 ? <Badge tone="amber">{item.reminderLevel}. Mahnung</Badge> : item.paidCents > 0 ? <Badge tone="blue">Teilbezahlt</Badge> : <Badge dot>Offen</Badge>}</td><td className="action-cell">{remaining > 0 ? <button className="row-action" onClick={() => onPayment(item)} aria-label={`Zahlung für ${item.member.name} buchen`} title="Zahlung buchen"><ArrowUpRight size={16} /></button> : <span className="paid-check"><Check size={16} /></span>}</td></tr>;
  })}</tbody></table>{items.length === 0 && <EmptyState title="Keine Beiträge gefunden" description="Wähle einen anderen Filter oder lege einen neuen Beitragslauf an." />}</div>;
}

export function EventRow({ event, onClick }: { event: ClubEvent; onClick: () => void }) {
  return <button className="event-row" onClick={onClick}><span className="date-tile"><small>{monthShort(event.date)}</small><strong>{Number(event.date.slice(8, 10))}</strong></span><span className="event-row-content"><strong>{event.title}</strong><span className="event-meta"><span><Clock3 size={12} />{event.time} Uhr</span><span><MapPin size={12} />{event.location}</span></span></span><Badge tone={event.type === "Turnier" ? "amber" : event.location === "Vereinsheim" ? "green" : "neutral"}>{event.type === "Turnier" ? "Turnier" : event.type === "Mannschaft" ? event.location === "Vereinsheim" ? "Heimspiel" : "Auswärtsspiel" : event.type}</Badge><ChevronRight className="event-chevron" size={17} /></button>;
}

export function downloadEvent(event: ClubEvent) {
  const escape = (value: string) => value.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
  const start = event.date.replaceAll("-", "") + "T" + event.time.replace(":", "") + "00";
  const content = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Schachclubmanager//Vereinskalender//DE", "CALSCALE:GREGORIAN", "BEGIN:VEVENT", `UID:${event.id}@schachclubmanager.local`, `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "")}`, `DTSTART;TZID=Europe/Berlin:${start}`, "DURATION:PT3H", `SUMMARY:${escape(event.title)}`, `LOCATION:${escape(event.location)}`, `DESCRIPTION:${escape(event.description)}`, "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  const url = URL.createObjectURL(new Blob([content], { type: "text/calendar;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = "Vereinstermin.ics"; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
