import { pgTable, text, integer, timestamp, date, uniqueIndex } from "drizzle-orm/pg-core";

export const members = pgTable("club_members", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull().default(""),
  address: text("address").notNull().default(""),
  category: text("category").notNull().default("Erwachsene"),
  status: text("status").notNull().default("Aktiv"),
  joinedAt: date("joined_at").notNull(),
  rating: integer("rating").notNull().default(0),
  color: text("color").notNull().default("sage"),
});

export const contributions = pgTable("club_contributions", {
  id: text("id").primaryKey(),
  memberId: text("member_id").notNull().references(() => members.id),
  year: integer("year").notNull(),
  totalCents: integer("total_cents").notNull(),
  paidCents: integer("paid_cents").notNull().default(0),
  reminderLevel: integer("reminder_level").notNull().default(0),
  dueDate: date("due_date").notNull(),
}, (table) => [uniqueIndex("club_contributions_member_year").on(table.memberId, table.year)]);

export const payments = pgTable("club_payments", {
  id: text("id").primaryKey(),
  contributionId: text("contribution_id").notNull().references(() => contributions.id),
  memberId: text("member_id").notNull().references(() => members.id),
  amountCents: integer("amount_cents").notNull(),
  method: text("method").notNull().default("Überweisung"),
  bookedAt: timestamp("booked_at", { mode: "string", withTimezone: true }).notNull().defaultNow(),
});

export const events = pgTable("club_events", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull(),
  date: date("date").notNull(),
  time: text("time").notNull(),
  location: text("location").notNull(),
  status: text("status").notNull().default("Geplant"),
  team: text("team").notNull().default(""),
  description: text("description").notNull().default(""),
  attendees: integer("attendees").notNull().default(0),
});

export const registrations = pgTable("club_registrations", {
  id: text("id").primaryKey(),
  eventId: text("event_id").notNull().references(() => events.id),
  memberName: text("member_name").notNull(),
}, (table) => [uniqueIndex("club_registration_unique").on(table.eventId, table.memberName)]);

export const requests = pgTable("club_requests", {
  id: text("id").primaryKey(),
  memberId: text("member_id").notNull().references(() => members.id),
  field: text("field").notNull(),
  oldValue: text("old_value").notNull(),
  newValue: text("new_value").notNull(),
  status: text("status").notNull().default("Offen"),
  createdAt: timestamp("created_at", { mode: "string", withTimezone: true }).notNull().defaultNow(),
});

export const activities = pgTable("club_activities", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(),
  createdAt: timestamp("created_at", { mode: "string", withTimezone: true }).notNull().defaultNow(),
});

export const announcements = pgTable("club_announcements", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { mode: "string", withTimezone: true }).notNull().defaultNow(),
});

export const settings = pgTable("club_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});
