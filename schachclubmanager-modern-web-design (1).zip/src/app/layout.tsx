import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/dm-sans/index.css";
import "@fontsource/instrument-serif/400.css";
import "@fontsource/instrument-serif/400-italic.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { CLUB_INFO } from "@/lib/club-config";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: `${CLUB_INFO.name} | Schach in Köln-Ehrenfeld`,
    template: `%s | ${CLUB_INFO.name}`,
  },
  description:
    "Schachklub Zugzwang Ehrenfeld 1924 e.V. – Seit über 100 Jahren Schachkultur in Köln. Jugendtraining, offene Vereinsabende, Ligateams und Turniere in der Alten Wagenhalle.",
  openGraph: {
    title: `${CLUB_INFO.fullName}`,
    description: "Kein Zug ohne Gedanken. Kein Abend ohne Freude. Schach in Köln-Ehrenfeld seit 1924.",
    type: "website",
    locale: "de_DE",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <body>
        <SiteHeader />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
