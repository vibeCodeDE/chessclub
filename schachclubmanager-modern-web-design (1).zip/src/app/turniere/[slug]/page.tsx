import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, CalendarDays, Clock3, MapPin, Timer, UsersRound } from "lucide-react";
import { TournamentRegistrationForm } from "@/components/forms";
import { CLUB_INFO } from "@/lib/club-config";
import { getTournament, getTournamentRegistrationCount } from "@/lib/club-data";
import { dateParts, formatLongDate } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const tournament = await getTournament(slug);
  return {
    title: tournament?.title ?? "Turnier nicht gefunden",
    description: tournament?.description,
  };
}

export default async function TournamentDetailPage({ params }: Props) {
  const { slug } = await params;
  const tournament = await getTournament(slug);
  if (!tournament) notFound();
  const registered = await getTournamentRegistrationCount(slug);
  const spotsLeft = Math.max(0, tournament.capacity - registered);
  const isOpen = tournament.status === "open" && spotsLeft > 0;
  const date = dateParts(tournament.date);

  return (
    <main className="inner-page tournament-detail">
      <div className="container">
        <Link href="/turniere" className="back-link tournament-back">
          <ArrowLeft size={17} strokeWidth={1.7} /> Alle Turniere
        </Link>
      </div>

      <section className="container tournament-detail-hero">
        <div className="tournament-hero-copy">
          <span className="eyebrow">
            <span className="eyebrow-dot" /> {CLUB_INFO.shortName.toUpperCase()} / TURNIER-SERIE 2026
          </span>
          <h1>{tournament.title}</h1>
          <p>
            Ein toller Schachabend in der Alten Wagenhalle. 
            Wir freuen uns auf vertraute Vereinsgesichter und neue Gäste aus ganz Köln und dem Rheinland.
          </p>
          {isOpen && (
            <Link href="#anmeldung" className="button button-lime">
              Jetzt anmelden <ArrowUpRight size={19} strokeWidth={1.8} />
            </Link>
          )}
        </div>
        <div className="tournament-hero-date">
          <span className="hero-date-top">TERMIN</span>
          <strong>{date.day}</strong>
          <span className="hero-date-month">
            {date.month} / {tournament.date.slice(0, 4)}
          </span>
          <span className="hero-date-knight" aria-hidden="true">♞</span>
        </div>
      </section>

      <section className="container tournament-details-grid">
        <div className="tournament-description">
          <div className="eyebrow section-eyebrow">
            <span className="small-rule" /> TURNIERINFORMATIONEN
          </div>
          <h2>
            Schach. Taktik.<br />
            <em>Gemeinschaft.</em>
          </h2>
          <p>{tournament.description}</p>
          <p>
            Holzbretter, digitale Schachuhren und Notationsformulare werden vom Verein gestellt. 
            Für Heiß- und Kaltgetränke ist an unserer Klub-Bar gesorgt.
          </p>
        </div>

        <div className="tournament-facts">
          <h3>Die Eckdaten</h3>
          <div className="fact-row">
            <CalendarDays size={21} strokeWidth={1.5} />
            <div>
              <span>DATUM</span>
              <strong>{formatLongDate(tournament.date)}</strong>
            </div>
          </div>
          <div className="fact-row">
            <Clock3 size={21} strokeWidth={1.5} />
            <div>
              <span>BEGINN</span>
              <strong>{tournament.time} Uhr (Einlass ab 30 Min. vorher)</strong>
            </div>
          </div>
          <div className="fact-row">
            <MapPin size={21} strokeWidth={1.5} />
            <div>
              <span>SPIELORT</span>
              <strong>{tournament.location}</strong>
            </div>
          </div>
          <div className="fact-row">
            <Timer size={21} strokeWidth={1.5} />
            <div>
              <span>TURNIERMODUS</span>
              <strong>{tournament.rounds} · {tournament.timeControl}</strong>
            </div>
          </div>
          <div className="fact-row">
            <UsersRound size={21} strokeWidth={1.5} />
            <div>
              <span>TEILNAHME</span>
              <strong>Offen für Mitglieder, Gäste & Vereinlose</strong>
            </div>
          </div>
        </div>
      </section>

      <section className="registration-section" id="anmeldung" aria-labelledby="registration-title">
        <div className="container registration-grid">
          <div className="registration-main">
            <div className="eyebrow section-eyebrow">
              <span className="small-rule" /> ANMELDUNG
            </div>
            <h2 id="registration-title">
              Sichere dir deinen <em>Platz.</em>
            </h2>
            <p>
              Trage dich unverbindlich in die Teilnehmerliste für das {tournament.title} ein. 
              Du erhältst eine Bestätigung und alle Infos zum Ablauf.
            </p>
            {isOpen ? (
              <TournamentRegistrationForm tournamentSlug={tournament.slug} />
            ) : (
              <div className="closed-notice">
                Die Anmeldung für dieses Turnier ist aktuell leider geschlossen oder voll besetzt. 
                Schau gerne bei unseren nächsten Terminen vorbei!
              </div>
            )}
          </div>

          <aside className="registration-aside">
            <span className="eyebrow">TEILNEHMERPLÄTZE</span>
            <strong>{spotsLeft.toString().padStart(2, "0")}</strong>
            <span>Plätze aktuell noch frei</span>
            <div className="registration-aside-rule" />
            <p>Fragen zu Startgeld, Wertung oder Anreise?</p>
            <Link href={`mailto:${CLUB_INFO.email}`}>
              Turnierleitung anschreiben <ArrowUpRight size={17} strokeWidth={1.7} />
            </Link>
          </aside>
        </div>
      </section>
    </main>
  );
}
