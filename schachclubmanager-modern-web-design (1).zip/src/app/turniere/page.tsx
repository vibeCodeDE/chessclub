import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";
import { getTournaments } from "@/lib/club-data";
import { dateParts, formatLongDate } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Turniere & Pokale",
  description: `Offene Turniere, Schnellschach und Blitzpokale beim ${CLUB_INFO.fullName}.`,
};

export default async function TournamentsPage() {
  const events = await getTournaments();

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link">
          <ArrowLeft size={17} strokeWidth={1.7} /> Startseite
        </Link>
        <div className="eyebrow section-eyebrow">
          <span className="small-rule" /> TURNIERKALENDER & POKALE
        </div>
        <h1>
          Dein nächster <em>Zug am Brett.</em>
        </h1>
        <p>
          Ein Schachturnier in der Alten Wagenhalle ist mehr als nur DWZ-Punkte: 
          Es sind packende Zeitnotphasen, faire Duelle und beste Gesellschaft an der Klub-Bar.
        </p>
      </section>

      <section className="container tournament-index" aria-labelledby="tournament-list-title">
        <div className="index-label-row">
          <span id="tournament-list-title">ANSTEHENDE TURNIERE</span>
          <span>SAISON 2026 / 27 · KÖLN-EHRENFELD</span>
        </div>
        {events.map((event) => {
          const date = dateParts(event.date);
          return (
            <article className="tournament-index-item" key={event.slug}>
              <div className="tournament-date-large">
                <strong>{date.day}</strong>
                <span>
                  {date.month} / {event.date.slice(0, 4)}
                </span>
              </div>
              <div className="tournament-index-copy">
                <span className="item-kicker">
                  <span className="open-dot" /> ANMELDUNG {event.status === "open" ? "OFFEN" : "GESCHLOSSEN"} · {event.format.toUpperCase()}
                </span>
                <h2>{event.title}</h2>
                <p>{event.description}</p>
                <div className="tournament-inline-facts">
                  <span>
                    <Clock3 size={16} strokeWidth={1.7} /> {formatLongDate(event.date)} · {event.time} Uhr
                  </span>
                  <span>
                    <MapPin size={16} strokeWidth={1.7} /> {event.location}
                  </span>
                </div>
              </div>
              <Link
                href={`/turniere/${event.slug}`}
                className="round-arrow"
                aria-label={`${event.title} ansehen und anmelden`}
              >
                <ArrowUpRight size={26} strokeWidth={1.5} />
              </Link>
            </article>
          );
        })}
        {events.length === 0 && (
          <p className="empty-message">Aktuell sind keine Turniere geplant. Schau bald wieder vorbei!</p>
        )}
      </section>

      <section className="container tournament-bottom-note">
        <div>
          <span className="eyebrow">GUT ZU WISSEN</span>
          <h2>Offen für alle Spielstärken & Gäste.</h2>
          <p>
            Du musst kein Vereinsmitglied sein, um bei unseren Turnieren mitzuspielen. 
            Bei Fragen zur Bedenkzeit oder zum Ablauf erreichst du unsere Turnierleitung jederzeit per E-Mail.
          </p>
        </div>
        <Link href={`mailto:${CLUB_INFO.email}`} className="underlined-link">
          Frage an Turnierleitung <ArrowRight size={18} strokeWidth={1.7} />
        </Link>
      </section>
    </main>
  );
}
