import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight, MapPin } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";
import { getMatches } from "@/lib/club-data";
import { dateParts, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Der Klub",
  description: `Geschichte, Spielbetrieb, Trainingszeiten und das Vereinsleben beim ${CLUB_INFO.fullName}.`,
};

export default async function ClubPage() {
  const fixtures = await getMatches();

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link">
          <ArrowLeft size={17} strokeWidth={1.7} /> Startseite
        </Link>
        <div className="eyebrow section-eyebrow">
          <span className="small-rule" /> SEIT 1924 IN KÖLN-EHRENFELD
        </div>
        <h1>
          Tradition, Taktik & <em>gute Züge.</em>
        </h1>
        <p>
          Wir lieben das tiefe Nachdenken am Brett genauso wie das Lachen und Diskutieren danach. 
          Lerne die Geschichte und die Menschen hinter Zugzwang Ehrenfeld kennen.
        </p>
      </section>

      <section className="container club-story-grid" aria-labelledby="story-title">
        <div className="club-story-photo">
          <Image
            src="/images/chess-community.jpg"
            alt="Spieler beim Analysieren einer Stellung in der Alten Wagenhalle"
            fill
            sizes="(max-width: 850px) 100vw, 50vw"
            className="cover-image"
          />
          <span>ALTE WAGENHALLE · LICHTSTRASSE 24</span>
        </div>
        <div className="club-story-copy">
          <div className="eyebrow section-eyebrow">
            <span className="small-rule" /> UNSERE PHILOSOPHIE
          </div>
          <h2 id="story-title">
            Schach ohne <em>Dünkel.</em>
          </h2>
          <p>
            1924 gründeten sieben Ehrenfelder Handwerker und Eisenbahner unseren Klub im Hinterzimmer einer Gaststätte. 
            Ihr Leitgedanke gilt bis heute: Schach ist für alle da. Bei uns sitzen Großmeister-Begeisterte 
            neben Leuten, die erst vor zwei Monaten das Schäfermatt überwunden haben.
          </p>
          <p>
            Vier Mannschaften kämpfen am Wochenende um Wertungspunkte in der Verbandsliga, 
            Bezirksklasse und Jugendliga. Donnerstags zählt vor allem der Spaß am gemeinsamen Spiel.
          </p>
          <Link href="/mitglied-werden" className="underlined-link">
            Komm auf ein Probespiel vorbei <ArrowUpRight size={18} strokeWidth={1.7} />
          </Link>
        </div>
      </section>

      <section className="training-section section-space" id="training" aria-labelledby="training-title">
        <div className="container">
          <div className="section-heading-row">
            <div>
              <div className="eyebrow section-eyebrow">
                <span className="small-rule" /> JEDE WOCHE AM BRETT
              </div>
              <h2 id="training-title" className="section-title">
                Trainieren & <em>Spielen.</em>
              </h2>
            </div>
            <p className="section-aside">
              Einfach ohne Voranmeldung reinschauen. <br />
              Wir finden immer die passende Spielstärke für dich.
            </p>
          </div>
          <div className="training-grid">
            <div className="training-item">
              <span className="training-number">01 / JUGEND & EINSTEIGER</span>
              <h3>Jugendtraining</h3>
              <strong>{CLUB_INFO.youthHours}</strong>
              <p>
                Geleitet von lizenzierten Vereinstrainern. Taktikaufgaben, Eröffnungsgrundlagen 
                und freies Spiel in entspannter Runde für Kinder und Teenager ab 7 Jahren.
              </p>
            </div>
            <div className="training-item">
              <span className="training-number">02 / DER HERZSCHLAG</span>
              <h3>Offener Klubabend</h3>
              <strong>{CLUB_INFO.clubNightHours}</strong>
              <p>
                Freie Partien, Blitz-Turniere, Partieanalysen und Austausch bei frischem Espresso 
                oder einem kühlen Getränk. Offen für Mitglieder und Gäste.
              </p>
            </div>
            <div className="training-location">
              <MapPin size={24} strokeWidth={1.5} />
              <span>UNSER KLUBRAUM</span>
              <strong>
                Alte Wagenhalle<br />
                Lichtstraße 24
              </strong>
              <p>
                50825 Köln-Ehrenfeld · Nur 3 Gehminuten vom Bahnhof Köln-Ehrenfeld (S12/S19, RE1/RE9) 
                oder U-Bahn Venloer Str./Gürtel (Linien 3, 4, 13).
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="container schedule-section section-space" id="spielplan" aria-labelledby="schedule-title">
        <div className="section-heading-row">
          <div>
            <div className="eyebrow section-eyebrow">
              <span className="small-rule" /> SAISON 2026 / 27
            </div>
            <h2 id="schedule-title" className="section-title">
              Ligabetrieb & <em>Termine.</em>
            </h2>
          </div>
          <p className="section-aside">
            Zuschauen & Mitfiebern bei Heimspielen in der Wagenhalle ist ausdrücklich erwünscht!
          </p>
        </div>
        <div className="schedule-table">
          <div className="schedule-head">
            <span>DATUM</span>
            <span>TEAM</span>
            <span>BEGEGNUNG</span>
            <span>UHRZEIT / ORT</span>
          </div>
          {fixtures.map((match) => {
            const date = dateParts(match.date);
            return (
              <div className="schedule-row" key={match.id}>
                <time dateTime={match.date} className="schedule-date">
                  <strong>{date.day}</strong>
                  <span>
                    {date.month} <small>{match.date.slice(0, 4)}</small>
                  </span>
                </time>
                <strong className="schedule-team">{match.team}</strong>
                <span className="schedule-opponent">
                  {match.home ? "gegen" : "bei"} {match.opponent}
                </span>
                <span className="schedule-place">
                  {formatDate(match.date)} · {match.time} Uhr
                  <br />
                  <small>{match.location}</small>
                </span>
              </div>
            );
          })}
        </div>
      </section>

      <section className="container club-bottom-cta">
        <div>
          <div className="eyebrow">
            <span className="eyebrow-dot" /> DEIN ERSTER ZUG
          </div>
          <h2>
            Lust auf ein <em>Probespiel?</em>
          </h2>
          <p>
            Komm donnerstags einfach vorbei oder schreib uns eine kurze Nachricht. 
            Wir freuen uns darauf, dich kennenzulernen!
          </p>
        </div>
        <Link href="/mitglied-werden" className="button button-lime">
          Kontakt aufnehmen <ArrowRight size={19} strokeWidth={1.7} />
        </Link>
      </section>
    </main>
  );
}
