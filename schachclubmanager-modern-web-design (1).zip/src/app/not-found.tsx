import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <main className="not-found-page"><div className="container not-found-inner"><span className="eyebrow"><span className="small-rule" /> 404 / SEITE NICHT GEFUNDEN</span><span className="not-found-symbol" aria-hidden="true">♞</span><h1>Dieser Zug ging <em>ins Leere.</em></h1><p>Die gesuchte Seite gibt es hier nicht. Auf der Startseite findest du bestimmt den richtigen Weg.</p><Link href="/" className="button button-dark"><ArrowLeft size={18} strokeWidth={1.7} /> Zur Startseite</Link></div></main>
  );
}
