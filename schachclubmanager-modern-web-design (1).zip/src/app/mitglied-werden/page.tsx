import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { MembershipForm } from "@/components/forms";
import { CLUB_INFO } from "@/lib/club-config";

export const metadata: Metadata = {
  title: "Mitglied werden & Probespiel",
  description: `Lerne den ${CLUB_INFO.fullName} kennen – schau einfach donnerstags in der Alten Wagenhalle vorbei oder schreib uns.`,
};

export default function MembershipPage() {
  return (
    <main className="inner-page membership-page">
      <section className="page-intro container">
        <Link href="/" className="back-link">
          <ArrowLeft size={17} strokeWidth={1.7} /> Startseite
        </Link>
        <div className="eyebrow section-eyebrow">
          <span className="small-rule" /> DER SCHRITT ZU UNS
        </div>
        <h1>
          Dein Platz am Brett in <em>Ehrenfeld.</em>
        </h1>
        <p>
          Ob du nach Jahren wieder einsteigst, gerade deine erste Eröffnung lernst oder 
          eine engagierte Mannschaft suchst: Bei uns bist du genau richtig.
        </p>
      </section>

      <section className="container membership-layout" aria-labelledby="membership-heading">
        <div className="membership-info">
          <div className="eyebrow section-eyebrow">
            <span className="small-rule" /> SO EINFACH GEHT'S
          </div>
          <h2 id="membership-heading">
            In drei Schritten <em>im Klub.</em>
          </h2>

          <div className="step-list">
            <div className="step-item">
              <span>01</span>
              <div>
                <h3>Nachricht oder Direktbesuch</h3>
                <p>
                  Schreib uns über das Formular oder komm einfach donnerstags ab 19:00 Uhr 
                  in die Alte Wagenhalle in Köln-Ehrenfeld.
                </p>
              </div>
            </div>
            <div className="step-item">
              <span>02</span>
              <div>
                <h3>Unverbindlich mitspielen</h3>
                <p>
                  Drei bis vier Klubabende lang kannst du völlig kostenlos reinschnuppern, 
                  Partien spielen, Leute kennenlernen und unseren Espresso probieren.
                </p>
              </div>
            </div>
            <div className="step-item">
              <span>03</span>
              <div>
                <h3>Gemeinsam entscheiden</h3>
                <p>
                  Wenn es dir gefällt, wirst du offizielles Mitglied, kannst eine DWZ-Zahl erspielen 
                  und auf Wunsch in einem unserer vier Liga-Teams mitspielen.
                </p>
              </div>
            </div>
          </div>

          <div className="membership-visit">
            <span className="eyebrow">DIREKTE ANREISE & ZEITEN</span>
            <p>
              <Clock3 size={18} strokeWidth={1.7} /> {CLUB_INFO.clubNightHours}
            </p>
            <p>
              <MapPin size={18} strokeWidth={1.7} /> {CLUB_INFO.clubhouse}
            </p>
            <Link href={`mailto:${CLUB_INFO.boardEmail}`}>
              Direkt an den Vorstand schreiben <ArrowUpRight size={17} strokeWidth={1.7} />
            </Link>
          </div>
        </div>

        <div className="membership-form-panel">
          <span className="eyebrow">UNVERBINDLICHE ANFRAGE</span>
          <h2>
            Sag einfach <em>Hallo.</em>
          </h2>
          <p>
            Erzähl uns kurz von deiner Schacherfahrung. 
            Wir antworten dir persönlich und reservieren dir ein Brett für den nächsten Donnerstag.
          </p>
          <MembershipForm />
        </div>
      </section>
    </main>
  );
}
