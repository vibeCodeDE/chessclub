import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";
import { getHomeData } from "@/lib/club-data";
import { dateParts, formatDateWithMonth } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { news, fixtures, events } = await getHomeData();
  const nextEvent = events[0];
  const stats = [
    { number: CLUB_INFO.stats.members, label: "AKTIVE MITGLIEDER", detail: "von 8 bis 84 Jahren" },
    { number: CLUB_INFO.stats.teams, label: "LIGA-TEAMS", detail: "von U16 bis Verbandsliga" },
    { number: String(events.length).padStart(2, "0"), label: "TURNIERE GEPLANT", detail: "Herbst-Open & Nachtblitz" },
    { number: "102", label: "JAHRE SCHACHTRADITION", detail: "gegründet im Oktober 1924" },
  ];

  return (
    <main>
      <section className="home-hero" aria-labelledby="hero-title">
        <div className="container hero-grid">
          <div className="hero-copy">
            <div className="eyebrow hero-eyebrow">
              <span className="eyebrow-dot" /> {CLUB_INFO.fullName.toUpperCase()}
            </div>
            <h1 id="hero-title">
              Schachkultur mit Herz in <em>Ehrenfeld.</em>
            </h1>
            <p className="hero-intro">
              Ob dein erster Bauernzug oder deine 100. Verbandsliga-Partie: Bei uns findest du 
              knisternde Turnierbretter, ehrliche Analysen und besten Espresso in der Alten Wagenhalle.
            </p>
            <div className="hero-actions">
              <Link href="/verein" className="button button-dark">
                Über unseren Klub <ArrowUpRight size={19} strokeWidth={1.8} />
              </Link>
              <Link href="/mitglied-werden" className="underlined-link">
                Probespiel vereinbaren <ArrowUpRight size={17} strokeWidth={1.8} />
              </Link>
            </div>
            <div className="hero-footnote">
              <span className="footnote-line" /> Ein Holzbrett und ein Stuhl sind immer für dich frei.
            </div>
          </div>
          <div className="hero-media">
            <div className="hero-image-frame">
              <Image
                src="/images/chess-game.jpg"
                alt="Intensive Schachpartie in der Alten Wagenhalle Köln-Ehrenfeld"
                fill
                priority
                sizes="(max-width: 850px) 100vw, 50vw"
                className="cover-image hero-image"
              />
              <span className="image-side-note">ZUGZWANG EHRENFELD / 1924</span>
            </div>
            {nextEvent && (
              <Link href={`/turniere/${nextEvent.slug}`} className="hero-event-card">
                <span className="event-card-top">
                  ALS NÄCHSTES IM KLUB <ArrowUpRight size={18} strokeWidth={1.7} />
                </span>
                <strong>{nextEvent.title}</strong>
                <span className="event-card-date">
                  {formatDateWithMonth(nextEvent.date)} · {nextEvent.time} Uhr
                </span>
              </Link>
            )}
          </div>
        </div>
      </section>

      <section className="weekly-band" aria-label="Klubabend">
        <div className="container weekly-inner">
          <span className="weekly-label">
            <span className="status-dot" /> JEDE WOCHE GEÖFFNET
          </span>
          <strong>Donnerstags ist Klubabend & offene Analyse.</strong>
          <span className="weekly-detail">
            <Clock3 size={17} strokeWidth={1.7} /> Jugend 17:30 Uhr · Erwachsene ab 19:00 Uhr
          </span>
          <span className="weekly-detail">
            <MapPin size={17} strokeWidth={1.7} /> {CLUB_INFO.shortLocation}
          </span>
          <Link href="/verein#training" aria-label="Mehr zum Klubabend">
            <ArrowUpRight size={21} strokeWidth={1.7} />
          </Link>
        </div>
      </section>

      <section className="overview-section section-space" aria-labelledby="overview-title">
        <div className="container">
          <div className="section-heading-row">
            <div>
              <div className="eyebrow section-eyebrow">
                <span className="small-rule" /> UNSER VEREIN
              </div>
              <h2 id="overview-title" className="section-title">
                Auf einen <em>Blick.</em>
              </h2>
            </div>
            <p className="section-aside">
              Zwischen Kaffeeduft, Turnierspannung und Vereinsgemeinschaft. <br />
              Saison 2026/27 in Köln-Ehrenfeld.
            </p>
          </div>
          <div className="stats-grid">
            {stats.map((stat) => (
              <div className="stat-item" key={stat.label}>
                <strong>{stat.number}</strong>
                <span className="stat-label">{stat.label}</span>
                <span className="stat-detail">{stat.detail}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="updates-section section-space" aria-labelledby="updates-title">
        <div className="container">
          <div className="section-heading-row updates-heading">
            <div>
              <div className="eyebrow section-eyebrow">
                <span className="small-rule" /> AUS DEM KLUBRAUM
              </div>
              <h2 id="updates-title" className="section-title">
                Neues vom <em>Brett.</em>
              </h2>
            </div>
            <Link className="section-more" href="/aktuelles">
              Alle Berichte lesen <ArrowUpRight size={19} strokeWidth={1.7} />
            </Link>
          </div>
          <div className="updates-grid">
            <div className="news-list">
              {news.map((article) => {
                const date = dateParts(article.publishedAt);
                return (
                  <Link className="news-row" href={`/aktuelles/${article.slug}`} key={article.slug}>
                    <time dateTime={article.publishedAt} className="news-date">
                      <strong>{date.day}</strong>
                      <span>{date.month}</span>
                    </time>
                    <div className="news-content">
                      <span className="item-kicker">
                        {article.category} <span>·</span> {formatDateWithMonth(article.publishedAt)}
                      </span>
                      <h3>{article.title}</h3>
                      <p>{article.excerpt}</p>
                    </div>
                    <ArrowUpRight className="news-arrow" size={21} strokeWidth={1.6} aria-hidden="true" />
                  </Link>
                );
              })}
              <Link className="news-bottom-link" href="/aktuelles">
                Weitere Geschichten aus dem Archiv <ArrowRight size={18} strokeWidth={1.7} />
              </Link>
            </div>
            <aside className="fixtures-panel" aria-labelledby="fixtures-title">
              <div className="fixtures-heading">
                <span className="eyebrow">LIGABETRIEB / 2026–27</span>
                <h3 id="fixtures-title">
                  Die nächsten <em>Begegnungen.</em>
                </h3>
              </div>
              <div className="fixture-list">
                {fixtures.slice(0, 3).map((match) => {
                  const date = dateParts(match.date);
                  return (
                    <div className="fixture-item" key={match.id}>
                      <time dateTime={match.date} className="fixture-date">
                        <strong>{date.day}</strong>
                        <span>{date.month}</span>
                      </time>
                      <div>
                        <span className="fixture-team">{match.team}</span>
                        <strong className="fixture-opponent">vs. {match.opponent}</strong>
                        <span className="fixture-meta">
                          {match.time} Uhr · {match.home ? "Heim (Wagenhalle)" : "Auswärts"}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
              <Link href="/verein#spielplan" className="fixtures-link">
                Kompletten Spielplan ansehen <ArrowUpRight size={18} strokeWidth={1.7} />
              </Link>
            </aside>
          </div>
        </div>
      </section>

      {nextEvent && (
        <section className="featured-section section-space" aria-labelledby="featured-title">
          <div className="container feature-grid">
            <div className="feature-copy">
              <div className="eyebrow feature-eyebrow">
                <span className="eyebrow-dot" /> NÄCHSTES TURNIER · {formatDateWithMonth(nextEvent.date).toUpperCase()}
              </div>
              <h2 id="featured-title">
                {nextEvent.title.replace(" 2026", "")}.<br />
                <em>Bereit für den Zug?</em>
              </h2>
              <p>{nextEvent.description}</p>
              <div className="feature-facts">
                <span>{nextEvent.rounds}</span>
                <span>{nextEvent.timeControl}</span>
                <span>Offen für Gäste & Mitglieder</span>
              </div>
              <Link href={`/turniere/${nextEvent.slug}`} className="button button-lime">
                Zum Turnier & Platz reservieren <ArrowUpRight size={19} strokeWidth={1.8} />
              </Link>
            </div>
            <div className="feature-photo">
              <Image
                src="/images/chess-pieces.jpg"
                alt="Klassische Staunton-Holzfiguren in der Alten Wagenhalle"
                fill
                sizes="(max-width: 850px) 100vw, 45vw"
                className="cover-image"
              />
              <span className="photo-caption">01 / SCHNELLSCHACH & BLITZ</span>
            </div>
          </div>
        </section>
      )}

      <section className="join-section section-space" aria-labelledby="join-title">
        <div className="container join-grid">
          <div className="join-photo">
            <Image
              src="/images/chess-community.jpg"
              alt="Gemeinsame Partien und Gespräche beim Klubabend in Köln-Ehrenfeld"
              fill
              sizes="(max-width: 850px) 100vw, 45vw"
              className="cover-image"
            />
          </div>
          <div className="join-copy">
            <div className="eyebrow section-eyebrow">
              <span className="small-rule" /> EINFACH MITMACHEN
            </div>
            <h2 id="join-title">
              Komm vorbei.<br />
              <em>Spiel mit uns.</em>
            </h2>
            <p>
              Du brauchst keinen Titel, keine Vereinsvorkenntnisse und keinen Anzug. 
              Komm einfach an einem Donnerstag vorbei, schnapp dir ein Getränk und spiel eine Partie mit.
            </p>
            <div className="join-time">
              <span>JUGENDTRAINING</span>
              <strong>{CLUB_INFO.youthHours}</strong>
            </div>
            <div className="join-time">
              <span>OFFENER KLUBABEND</span>
              <strong>{CLUB_INFO.clubNightHours}</strong>
            </div>
            <Link href="/mitglied-werden" className="button button-dark">
              Probespiel anfragen <ArrowUpRight size={19} strokeWidth={1.8} />
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
