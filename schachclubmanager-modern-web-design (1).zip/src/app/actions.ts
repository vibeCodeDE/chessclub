"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { membershipRequests, tournamentRegistrations } from "@/db/schema";
import { getTournament, getTournamentRegistrationCount } from "@/lib/club-data";

export type FormState = {
  status: "idle" | "success" | "error";
  message: string;
};

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function field(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

export async function submitMembershipRequest(_previous: FormState, formData: FormData): Promise<FormState> {
  const name = field(formData, "name");
  const email = field(formData, "email").toLowerCase();
  const experience = field(formData, "experience");
  const message = field(formData, "message");

  if (field(formData, "website")) {
    return { status: "success", message: "Danke! Deine Anfrage ist bei uns angekommen." };
  }
  if (name.length < 2 || name.length > 160 || !emailPattern.test(email) || email.length > 255) {
    return { status: "error", message: "Bitte gib einen Namen und eine gültige E-Mail-Adresse ein." };
  }
  if (!experience || experience.length > 80 || message.length > 2000) {
    return { status: "error", message: "Bitte prüfe deine Angaben und versuche es erneut." };
  }
  if (formData.get("privacy") !== "on") {
    return { status: "error", message: "Bitte bestätige die Hinweise zur Verarbeitung deiner Anfrage." };
  }

  try {
    await db.insert(membershipRequests).values({
      name,
      email,
      experience,
      message: message || null,
      privacyAccepted: true,
    });
    return { status: "success", message: "Danke für deine Nachricht! Wir melden uns bei dir und freuen uns aufs Kennenlernen." };
  } catch {
    return { status: "error", message: "Das hat leider nicht geklappt. Bitte versuche es später noch einmal oder schreib uns eine E-Mail." };
  }
}

export async function submitTournamentRegistration(_previous: FormState, formData: FormData): Promise<FormState> {
  const tournamentSlug = field(formData, "tournamentSlug");
  const name = field(formData, "name");
  const email = field(formData, "email").toLowerCase();
  const club = field(formData, "club");

  if (field(formData, "website")) {
    return { status: "success", message: "Danke! Deine Anmeldung ist bei uns angekommen." };
  }
  if (name.length < 2 || name.length > 160 || !emailPattern.test(email) || email.length > 255 || club.length > 160) {
    return { status: "error", message: "Bitte gib einen Namen und eine gültige E-Mail-Adresse ein." };
  }
  if (formData.get("privacy") !== "on") {
    return { status: "error", message: "Bitte bestätige die Hinweise zur Verarbeitung deiner Anmeldung." };
  }

  try {
    const tournament = await getTournament(tournamentSlug);
    if (!tournament || tournament.status !== "open") {
      return { status: "error", message: "Für dieses Turnier ist die Anmeldung derzeit nicht möglich." };
    }
    const registered = await getTournamentRegistrationCount(tournamentSlug);
    if (registered >= tournament.capacity) {
      return { status: "error", message: "Leider sind bereits alle Plätze vergeben." };
    }
    const inserted = await db
      .insert(tournamentRegistrations)
      .values({ tournamentSlug, name, email, club: club || null, privacyAccepted: true })
      .onConflictDoNothing()
      .returning({ id: tournamentRegistrations.id });

    if (inserted.length === 0) {
      return { status: "error", message: "Mit dieser E-Mail-Adresse bist du für das Turnier bereits angemeldet." };
    }
    revalidatePath(`/turniere/${tournamentSlug}`);
    return { status: "success", message: "Du stehst auf der Teilnehmerliste! Wir freuen uns auf deine Partie." };
  } catch {
    return { status: "error", message: "Die Anmeldung konnte nicht gespeichert werden. Bitte versuche es später erneut." };
  }
}
