import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";
import { getAnnouncements } from "@/lib/club-data";
import { dateParts, formatDateWithMonth } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Aktuelles",
  description: `Neuigkeiten, Spielberichte und Ankündigungen aus dem ${CLUB_INFO.fullName}.`,
};

const categories = ["Alle", "Spielbetrieb", "Jugend", "Vereinsleben", "Turnier", "Verein"];

type Props = { searchParams: Promise<{ thema?: string }> };

export default async function NewsPage({ searchParams }: Props) {
  const { thema } = await searchParams;
  const active = thema && categories.includes(thema) ? thema : "Alle";
  const articles = await getAnnouncements(active === "Alle" ? undefined : active);

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link">
          <ArrowLeft size={17} strokeWidth={1.7} /> Startseite
        </Link>
        <div className="eyebrow section-eyebrow">
          <span className="small-rule" /> NACHRICHTEN & PARTIEBERICHTE
        </div>
        <h1>
          Geschichten aus der <em>Wagenhalle.</em>
        </h1>
        <p>
          Spannende Ligaduelle, Jugenderfolge, neue Turnierbretter und Momente, die in Erinnerung bleiben. 
          Hier halten wir fest, was bei Zugzwang Ehrenfeld passiert.
        </p>
      </section>

      <section className="container index-section" aria-label="Neuigkeiten">
        <div className="filter-bar">
          <span>KATEGORIE</span>
          <div className="filter-links" aria-label="Nach Thema filtern">
            {categories.map((category) => (
              <Link
                key={category}
                href={category === "Alle" ? "/aktuelles" : `/aktuelles?thema=${encodeURIComponent(category)}`}
                className={active === category ? "selected" : ""}
                aria-current={active === category ? "page" : undefined}
              >
                {category}
              </Link>
            ))}
          </div>
        </div>

        <div className="index-grid">
          <div className="news-list index-news-list">
            {articles.map((article) => {
              const date = dateParts(article.publishedAt);
              return (
                <Link className="news-row" href={`/aktuelles/${article.slug}`} key={article.slug}>
                  <time dateTime={article.publishedAt} className="news-date">
                    <strong>{date.day}</strong>
                    <span>{date.month}</span>
                  </time>
                  <div className="news-content">
                    <span className="item-kicker">
                      {article.category} <span>·</span> {formatDateWithMonth(article.publishedAt)}
                    </span>
                    <h2>{article.title}</h2>
                    <p>{article.excerpt}</p>
                  </div>
                  <ArrowUpRight className="news-arrow" size={21} strokeWidth={1.6} aria-hidden="true" />
                </Link>
              );
            })}
            {articles.length === 0 && (
              <p className="empty-message">Zu dieser Kategorie gibt es aktuell noch keine Beiträge.</p>
            )}
          </div>

          <aside className="index-aside">
            <span className="eyebrow">MITMACHEN</span>
            <span className="aside-symbol" aria-hidden="true">♞</span>
            <h2>Die spannendsten Partien sind die ungespielten.</h2>
            <p>
              Komm donnerstags ab 19:00 Uhr in die Alte Wagenhalle. 
              Wir haben immer ein freies Brett und Menschen, die gerne analysieren.
            </p>
            <Link className="underlined-link" href="/verein#training">
              Klubabend entdecken <ArrowRight size={17} strokeWidth={1.7} />
            </Link>
          </aside>
        </div>
      </section>
    </main>
  );
}
