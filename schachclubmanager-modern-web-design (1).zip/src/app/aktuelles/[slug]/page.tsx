import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";
import { getAnnouncement, getAnnouncements } from "@/lib/club-data";
import { formatDateWithMonth } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const article = await getAnnouncement(slug);
  return {
    title: article?.title ?? "Beitrag nicht gefunden",
    description: article?.excerpt,
  };
}

export default async function ArticlePage({ params }: Props) {
  const { slug } = await params;
  const article = await getAnnouncement(slug);
  if (!article) notFound();
  const related = (await getAnnouncements()).filter((item) => item.slug !== slug).slice(0, 2);

  return (
    <main className="inner-page article-page">
      <div className="container article-layout">
        <article className="article-main">
          <Link href="/aktuelles" className="back-link">
            <ArrowLeft size={17} strokeWidth={1.7} /> Alle Berichte & Aktuelles
          </Link>
          <div className="eyebrow section-eyebrow">
            <span className="small-rule" /> {article.category.toUpperCase()} · {formatDateWithMonth(article.publishedAt).toUpperCase()}
          </div>
          <h1>{article.title}</h1>
          <p className="article-lead">{article.excerpt}</p>
          <div className="article-divider">
            <span aria-hidden="true">♞</span>
            <span>{CLUB_INFO.name.toUpperCase()} · VEREINSLEBEN</span>
          </div>
          <div className="article-body">
            {article.body.split("\n\n").map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
          <div className="article-end">
            <Link href="/aktuelles" className="underlined-link">
              <ArrowLeft size={17} strokeWidth={1.7} /> Zurück zu allen Beiträgen
            </Link>
          </div>
        </article>

        <aside className="article-sidebar">
          <div className="article-side-card">
            <span className="eyebrow">WEITERE BERICHTE</span>
            <h2>Immer etwas los am Brett.</h2>
            <div className="related-links">
              {related.map((item) => (
                <Link href={`/aktuelles/${item.slug}`} key={item.slug}>
                  <span>{item.category}</span>
                  <strong>{item.title}</strong>
                  <ArrowUpRight size={18} strokeWidth={1.7} />
                </Link>
              ))}
            </div>
          </div>
          <div className="article-side-bottom">
            <span>SPIEL MIT UNS</span>
            <p>Einfach donnerstags vorbeikommen, mitspielen und den Klub kennenlernen.</p>
            <Link href="/mitglied-werden">
              Probespiel vereinbaren <ArrowUpRight size={17} strokeWidth={1.7} />
            </Link>
          </div>
        </aside>
      </div>
    </main>
  );
}
