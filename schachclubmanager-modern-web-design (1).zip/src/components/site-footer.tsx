import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { CLUB_INFO } from "@/lib/club-config";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-main">
        <div className="footer-brand-block">
          <Link className="footer-logo" href="/">
            <span aria-hidden="true">♞</span> Zugzwang Ehrenfeld<span className="footer-logo-period">.</span>
          </Link>
          <p>
            Seit 1924 das Zuhause für leidenschaftliches Schach in Köln-Ehrenfeld. 
            Für Meisterzüge, Kaffeehaus-Blitz und alle, die zum ersten Mal eine Dame schlagen.
          </p>
        </div>
        <div className="footer-column">
          <span className="footer-label">ENTDECKEN</span>
          <Link href="/aktuelles">Aktuelles & Berichte</Link>
          <Link href="/turniere">Turniere & Pokale</Link>
          <Link href="/verein">Über den Klub & Chronik</Link>
          <Link href="/verein#spielplan">Ligaspielplan 2026/27</Link>
          <Link href="/mitglied-werden">Mitglied werden / Probespiel</Link>
        </div>
        <div className="footer-column">
          <span className="footer-label">KLUBRAUM & ZEITEN</span>
          <span>{CLUB_INFO.clubhouse}</span>
          <span>Jugend · {CLUB_INFO.youthHours}</span>
          <span>Klubabend · {CLUB_INFO.clubNightHours}</span>
          <Link className="footer-mail" href={`mailto:${CLUB_INFO.email}`}>
            {CLUB_INFO.email} <ArrowUpRight size={15} />
          </Link>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} {CLUB_INFO.fullName}. Gegründet 1924.</span>
        <span>Keine Tracker, keine Werbe-CDNs. Nur Schach, Kaffee und Gemeinschaft.</span>
      </div>
    </footer>
  );
}
