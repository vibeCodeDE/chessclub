"use client";

import Link from "next/link";
import { ArrowUpRight, Check } from "lucide-react";
import { useActionState } from "react";
import {
  submitMembershipRequest,
  submitTournamentRegistration,
  type FormState,
} from "@/app/actions";

const initialState: FormState = { status: "idle", message: "" };

function SuccessMessage({ message, linkHref, linkText }: { message: string; linkHref: string; linkText: string }) {
  return (
    <div className="form-success" role="status">
      <span className="success-icon"><Check size={25} strokeWidth={1.8} /></span>
      <h3>Wunderbar! Nachricht erhalten.</h3>
      <p>{message}</p>
      <Link href={linkHref} className="underlined-link">{linkText} <ArrowUpRight size={18} strokeWidth={1.8} /></Link>
    </div>
  );
}

export function MembershipForm() {
  const [state, action, pending] = useActionState(submitMembershipRequest, initialState);

  if (state.status === "success") {
    return (
      <SuccessMessage
        message={state.message}
        linkHref="/verein"
        linkText="Mehr über unseren Klub & Trainingszeiten"
      />
    );
  }

  return (
    <form action={action} className="club-form">
      <div className="form-row">
        <div className="form-field">
          <label htmlFor="membership-name">Dein Vor- und Nachname <span>*</span></label>
          <input
            id="membership-name"
            name="name"
            type="text"
            autoComplete="name"
            placeholder="z.B. Alex Becker"
            maxLength={160}
            required
          />
        </div>
        <div className="form-field">
          <label htmlFor="membership-email">Deine E-Mail-Adresse <span>*</span></label>
          <input
            id="membership-email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="z.B. alex@beispiel.de"
            maxLength={255}
            required
          />
        </div>
      </div>

      <div className="form-field">
        <label htmlFor="membership-experience">Wie schätzt du dein Schach ein? <span>*</span></label>
        <select id="membership-experience" name="experience" defaultValue="" required>
          <option value="" disabled>Bitte auswählen</option>
          <option value="Neu / Anfänger:in (Regeln sitzen, wenig Spielerfahrung)">
            Neu / Einsteiger:in (Regeln sitzen, wenig Spielerfahrung)
          </option>
          <option value="Hobbyspieler:in (regelmäßig online oder mit Freunden)">
            Hobbyspieler:in (regelmäßig online oder mit Freunden)
          </option>
          <option value="Erfahrene:r Vereinsspieler:in / DWZ vorhanden">
            Erfahrene:r Vereinsspieler:in / DWZ vorhanden
          </option>
          <option value="Elternteil für Jugendtraining (7–16 Jahre)">
            Elternteil / Interesse an Jugendtraining (7–16 Jahre)
          </option>
        </select>
      </div>

      <div className="form-field">
        <label htmlFor="membership-message">
          Möchtest du uns noch etwas mitteilen? <span className="optional">Optional</span>
        </label>
        <textarea
          id="membership-message"
          name="message"
          rows={4}
          maxLength={2000}
          placeholder="z.B. Wann möchtest du vorbeikommen? Hast du bestimmte Ziele oder Fragen?"
        />
      </div>

      <div className="trap-field" aria-hidden="true">
        <label htmlFor="membership-website">Website</label>
        <input id="membership-website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <label className="checkbox-field">
        <input type="checkbox" name="privacy" required />
        <span>
          Ich bin damit einverstanden, dass meine Kontaktdaten zur Beantwortung meiner Probespiel-Anfrage 
          vom SK Zugzwang Ehrenfeld verarbeitet werden. Keine Weitergabe an Dritte. <strong>*</strong>
        </span>
      </label>

      {state.status === "error" && <p className="form-error" role="alert">{state.message}</p>}

      <button type="submit" className="button button-dark form-submit" disabled={pending}>
        {pending ? "Wird übermittelt …" : "Anfrage unverbindlich senden"}{" "}
        <ArrowUpRight size={19} strokeWidth={1.8} />
      </button>
      <p className="form-note">* Pflichtangabe. Unser Vorstand antwortet dir in der Regel innerhalb von 24 Stunden.</p>
    </form>
  );
}

export function TournamentRegistrationForm({ tournamentSlug }: { tournamentSlug: string }) {
  const [state, action, pending] = useActionState(submitTournamentRegistration, initialState);

  if (state.status === "success") {
    return (
      <SuccessMessage
        message={state.message}
        linkHref="/turniere"
        linkText="Zurück zum Turnierkalender"
      />
    );
  }

  return (
    <form action={action} className="club-form">
      <input type="hidden" name="tournamentSlug" value={tournamentSlug} />
      <div className="form-row">
        <div className="form-field">
          <label htmlFor="tournament-name">Dein Name <span>*</span></label>
          <input
            id="tournament-name"
            name="name"
            type="text"
            autoComplete="name"
            placeholder="Vor- und Nachname"
            maxLength={160}
            required
          />
        </div>
        <div className="form-field">
          <label htmlFor="tournament-email">E-Mail-Adresse <span>*</span></label>
          <input
            id="tournament-email"
            name="email"
            type="email"
            autoComplete="email"
            placeholder="du@beispiel.de"
            maxLength={255}
            required
          />
        </div>
      </div>

      <div className="form-field">
        <label htmlFor="tournament-club">Aktueller Schachverein / DWZ <span className="optional">Optional</span></label>
        <input
          id="tournament-club"
          name="club"
          type="text"
          placeholder="z.B. vereinslos oder SK Zugzwang Ehrenfeld"
          maxLength={160}
        />
      </div>

      <div className="trap-field" aria-hidden="true">
        <label htmlFor="tournament-website">Website</label>
        <input id="tournament-website" name="website" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      <label className="checkbox-field">
        <input type="checkbox" name="privacy" required />
        <span>
          Ich bin damit einverstanden, dass meine Angaben für die Startliste und Durchführung des Turniers 
          gespeichert werden. <strong>*</strong>
        </span>
      </label>

      {state.status === "error" && <p className="form-error" role="alert">{state.message}</p>}

      <button type="submit" className="button button-dark form-submit" disabled={pending}>
        {pending ? "Wird eingetragen …" : "Für Startliste vormerken"}{" "}
        <ArrowUpRight size={19} strokeWidth={1.8} />
      </button>
      <p className="form-note">* Pflichtangabe. Die Startliste wird vor Ort in der Alten Wagenhalle ausgehängt.</p>
    </form>
  );
}
