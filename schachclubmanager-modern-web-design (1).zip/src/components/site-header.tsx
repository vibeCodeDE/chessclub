"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { useState } from "react";
import { CLUB_INFO } from "@/lib/club-config";

const navItems = [
  { href: "/", label: "Startseite" },
  { href: "/aktuelles", label: "Aktuelles" },
  { href: "/turniere", label: "Turniere" },
  { href: "/verein", label: "Der Klub" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link
          className="brand"
          href="/"
          aria-label={`${CLUB_INFO.fullName} – zur Startseite`}
          onClick={() => setMenuOpen(false)}
        >
          <span className="brand-mark" aria-hidden="true">♞</span>
          <span className="brand-type">
            <strong>Zugzwang Ehrenfeld<span className="brand-period">.</span></strong>
            <small>SCHACHKLUB SEIT {CLUB_INFO.founded} · KÖLN</small>
          </span>
        </Link>

        <nav
          className={`main-nav${menuOpen ? " is-open" : ""}`}
          id="main-navigation"
          aria-label="Hauptnavigation"
        >
          {navItems.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`nav-link${active ? " active" : ""}`}
                aria-current={active ? "page" : undefined}
                onClick={() => setMenuOpen(false)}
              >
                {item.label}
              </Link>
            );
          })}
          <Link
            className="mobile-join"
            href="/mitglied-werden"
            onClick={() => setMenuOpen(false)}
          >
            Mitglied werden <ArrowUpRight size={17} strokeWidth={1.8} />
          </Link>
        </nav>

        <Link className="header-join" href="/mitglied-werden">
          Mitglied werden <ArrowUpRight size={17} strokeWidth={1.8} />
        </Link>
        <button
          className="menu-toggle"
          type="button"
          aria-label={menuOpen ? "Menü schließen" : "Menü öffnen"}
          aria-expanded={menuOpen}
          aria-controls="main-navigation"
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={24} strokeWidth={1.8} /> : <Menu size={24} strokeWidth={1.8} />}
        </button>
      </div>
    </header>
  );
}
