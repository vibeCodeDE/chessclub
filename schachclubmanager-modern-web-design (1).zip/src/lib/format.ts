function localDate(value: string) {
  return new Date(`${value}T12:00:00`);
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat("de-DE", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(localDate(value));
}

export function formatLongDate(value: string) {
  return new Intl.DateTimeFormat("de-DE", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(localDate(value));
}

export function formatDateWithMonth(value: string) {
  return new Intl.DateTimeFormat("de-DE", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(localDate(value));
}

export function dateParts(value: string) {
  const date = localDate(value);
  return {
    day: new Intl.DateTimeFormat("de-DE", { day: "2-digit" }).format(date),
    month: new Intl.DateTimeFormat("de-DE", { month: "short" })
      .format(date)
      .replace(".", "")
      .toUpperCase(),
  };
}
