import { db } from "@/db";
import { announcements, matches, tournamentRegistrations, tournaments } from "@/db/schema";
import { asc, count, desc, eq } from "drizzle-orm";
import { CLUB_INFO } from "@/lib/club-config";

export { CLUB_INFO };

const announcementSeed: (typeof announcements.$inferInsert)[] = [
  {
    slug: "derby-sieg-gegen-nippes",
    title: "Derby-Krimi in der Verbandsliga: Brett 4 dreht die Partie",
    category: "Spielbetrieb",
    publishedAt: "2026-10-04",
    excerpt:
      "Nach viereinhalb Stunden stand das Stadtteil-Derby gegen die Schachfreunde Köln-Nippes auf Messers Schneide. Ein mutiges Figurenopfer brachte den entscheidenden Mannschaftspunkt.",
    body:
      "Es war das erwartet intensive Match in der Verbandsliga Mittelrhein: Der SK Zugzwang Ehrenfeld empfing die traditionsreichen Schachfreunde aus Nippes in unserer vollbesetzten Alten Wagenhalle.\n\nNach drei Remisen an den Spitzenbrettern und einem frühen Partieverlust auf Brett 6 sah es lange nach einer knappen Heimniederlage aus. Doch dann opferte Mira Lindemann an Brett 4 überraschend ihren Springer auf f7, zerriss die gegnerische Königsstellung und verwandelte die Stellung nach 54 Zügen in ein gewonnenes Damenendspiel.\n\nMit dem Endstand von 4,5 : 3,5 klettert unsere Erste auf Platz 2 der Tabelle. Ein riesiger Dank an alle Kiebitze, die bis nach 20 Uhr mitgefiebert und anschließend gemeinsam im Clubraum analysiert haben.",
    featured: true,
  },
  {
    slug: "jugend-grand-prix-ehrenfeld",
    title: "Drei Podestplätze beim Kölner Jugend-Grand-Prix",
    category: "Jugend",
    publishedAt: "2026-09-22",
    excerpt:
      "Unsere U14 und U16 haben beim Kölner Jugend-Grand-Prix ein bärenstarkes Turnier gespielt. Anton (1. Platz U14) und Lotte (2. Platz U16) qualifizieren sich für die Landesebene.",
    body:
      "Mit insgesamt neun Jugendlichen reiste unser Trainerteam um Hannes und Elena am Samstag zum Jugend-Grand-Prix nach Deutz. In sieben Runden Schweizer System bewiesen unsere Nachwuchsspielerinnen und -spieler nicht nur Nervenstärke, sondern auch saubere Endspieltechnik.\n\nAnton gewann seine U14-Gruppe ungeschlagen mit 6,5 aus 7 Punkten, während Lotte sich in der U16 mit einem spektakulären Mattangriff den zweiten Platz sicherte. Auch unsere Neueinsteiger Leo und Frida holten ihre ersten Turnierpunkte.\n\nDas wöchentliche Jugendtraining donnerstags um 17:30 Uhr zahlt sich aus – wir sind stolz auf euch!",
  },
  {
    slug: "neue-dgt-bretter-und-espresso",
    title: "Frischer Wind im Klubraum: Neue Turnierbretter und beste Bohnen",
    category: "Vereinsleben",
    publishedAt: "2026-09-12",
    excerpt:
      "Dank einer Spende unserer Ehrenmitglieder stehen ab sofort acht neue handgefertigte Holzturnierbretter und eine generalüberholte Siebträgermaschine im Vereinsheim bereit.",
    body:
      "Gute Züge brauchen gutes Holz und anständigen Kaffee. Dank der Unterstützung unserer Fördermitglieder konnten wir rechtzeitig zur neuen Saison acht wunderschöne DGT-Turnierbretter aus Nussbaum und Ahorn für die Alte Wagenhalle anschaffen.\n\nAußerdem duftet es donnerstags nun noch verlockender: Die generalüberholte zweigruppige Espressomaschine ist eingeweiht und wird von wechselnden Vereinsmitgliedern mit frischen Bohnen aus der Ehrenfelder Rösterei betrieben.\n\nKommt am Donnerstag ab 19:00 Uhr vorbei, probiert das neue Spielgefühl aus und trinkt einen Espresso mit uns am Brett.",
  },
  {
    slug: "herbst-open-2026-ankuendigung",
    title: "Ehrenfelder Herbst-Open 2026: Jetzt für das Traditionsturnier anmelden",
    category: "Turnier",
    publishedAt: "2026-09-01",
    excerpt:
      "5 Runden Schweizer System, 15 Minuten Bedenkzeit plus 5 Sekunden Inkrement. Das beliebte Herbstturnier für Vereinsmitglieder und Gäste geht in die nächste Runde.",
    body:
      "Am Dienstag, den 20. Oktober 2026, laden wir wieder zum offenen Ehrenfelder Herbst-Rapid in die Wagenhalle ein. Gespielt werden fünf spannende Runden im Schweizer System mit FIDE-konformer Schnellschach-Bedenkzeit (15 min + 5 s/Zug).\n\nDas Turnier ist offen für alle Spielstärken: vom vertrauten DWZ-Veteranen bis zum Hobby-Schachspieler, der zum ersten Mal Wettkampfluft schnuppern möchte. Für Verpflegung und Analyse-Bretter im Nebenraum ist wie gewohnt gesorgt.\n\nDie Teilnehmerzahl ist aus Platzgründen auf 36 Bretter begrenzt. Die Online-Anmeldung ist ab sofort freigeschaltet.",
  },
  {
    slug: "102-jahre-zugzwang-ehrenfeld",
    title: "102 Jahre Schach in Ehrenfeld: Ein Blick in unser Vereinsarchiv",
    category: "Verein",
    publishedAt: "2026-08-18",
    excerpt:
      "Im Oktober 1924 trafen sich sieben Fabrikarbeiter und Handwerker in der Gaststätte 'Zur Rheinischen Bahn' und gründeten unseren Klub. Eine kleine Reise durch ein Jahrhundert Schachkultur.",
    body:
      "Vor über 100 Jahren war Ehrenfeld geprägt von Maschinenbau, Glashütten und Metallverarbeitung. Genau dort, zwischen Schichtarbeit und Feierabend, entstand unser Schachklub. Die Idee: Ein Verein ohne Dünkel, offen für jeden, der Leidenschaft für das königliche Spiel mitbringt.\n\nÜber 100 Jahre später spielen bei uns Schülerinnen, Studierende, Ingenieure, Rentner und Kunstschaffende an denselben Brettern. Die Zeiten haben sich geändert – die Freude an einer tiefgründigen Taktik und einem ehrlichen Gespräch danach ist genau dieselbe geblieben.\n\nZur kommenden Mitgliederversammlung im November präsentieren wir eine kleine Chronik und alte Partiemitschriften aus den 1930er und 1950er Jahren.",
  },
];

const tournamentSeed: (typeof tournaments.$inferInsert)[] = [
  {
    slug: "ehrenfelder-herbst-open-2026",
    title: "Ehrenfelder Herbst-Open 2026",
    date: "2026-10-20",
    time: "19:00",
    location: "Alte Wagenhalle, Lichtstraße 24, Köln-Ehrenfeld",
    format: "Schnellschach (Rapid)",
    timeControl: "15 Min + 5 Sek / Zug",
    rounds: "5 Runden Schweizer System",
    description:
      "Das beliebte Ehrenfelder Herbstturnier bringt 36 Spielerinnen und Spieler aller Generationen an die Bretter. Fünf Runden Schnellschach, lockere Atmosphäre, Pokale für die Top 3 sowie Sonderpreise für die beste Jugendpartie und beste vereinlose Teilnehmende. Getränke und Snacks gibt es vor Ort in der Wagenhalle.",
    status: "open",
    capacity: 36,
  },
  {
    slug: "ehrenfelder-nachtblitz-pokal",
    title: "Ehrenfelder Nachtblitz-Pokal",
    date: "2026-11-17",
    time: "20:00",
    location: "Alte Wagenhalle, Lichtstraße 24, Köln-Ehrenfeld",
    format: "Blitzturnier (Night Blitz)",
    timeControl: "3 Min + 2 Sek / Zug",
    rounds: "9 Runden Schweizer System",
    description:
      "Wenn die Wagenhalle ins warme Scheinwerferlicht taucht, ticken die Uhren schneller: 9 Runden Vollgas-Schach im 3+2-Modus. Ideal für Fans scharfer Taktiken und schneller Entscheidungen. Im Anschluss: Freie Analyse und gemeinsamer Ausklang an der Club-Bar.",
    status: "open",
    capacity: 32,
  },
];

const matchSeed: (typeof matches.$inferInsert)[] = [
  {
    id: "2026-10-11-erste-koeln-nippes",
    team: "1. Mannschaft",
    opponent: "SF Köln-Nippes 1904",
    date: "2026-10-11",
    time: "10:00",
    location: "Alte Wagenhalle (Heimspiel)",
    home: true,
  },
  {
    id: "2026-10-18-u16-rochade-porz",
    team: "Jugend U16",
    opponent: "SG Porz U16",
    date: "2026-10-18",
    time: "14:00",
    location: "Köln-Porz (Auswärts)",
    home: false,
  },
  {
    id: "2026-10-25-zweite-deutzer-bruecke",
    team: "2. Mannschaft",
    opponent: "SV Deutzer Brücke",
    date: "2026-10-25",
    time: "10:00",
    location: "Alte Wagenhalle (Heimspiel)",
    home: true,
  },
  {
    id: "2026-11-08-erste-bonner-sv",
    team: "1. Mannschaft",
    opponent: "Bonner SV Beuel 1920",
    date: "2026-11-08",
    time: "10:00",
    location: "Bonn-Beuel (Auswärts)",
    home: false,
  },
  {
    id: "2026-11-15-dritte-lindenthal",
    team: "3. Mannschaft",
    opponent: "SC Turm Lindenthal II",
    date: "2026-11-15",
    time: "10:00",
    location: "Alte Wagenhalle (Heimspiel)",
    home: true,
  },
];

export async function resetAndSeedClubData() {
  await db.delete(tournamentRegistrations);
  await db.delete(announcements);
  await db.delete(tournaments);
  await db.delete(matches);

  await db.insert(announcements).values(announcementSeed);
  await db.insert(tournaments).values(tournamentSeed);
  await db.insert(matches).values(matchSeed);
}

let seedPromise: Promise<void> | undefined;

export async function ensureClubData() {
  if (!seedPromise) {
    seedPromise = (async () => {
      const existing = await db.select({ total: count() }).from(announcements);
      if ((existing[0]?.total ?? 0) === 0) {
        await resetAndSeedClubData();
      }
    })().catch((error) => {
      seedPromise = undefined;
      throw error;
    });
  }
  await seedPromise;
}

export async function getHomeData() {
  await ensureClubData();
  const [news, fixtures, events] = await Promise.all([
    db.select().from(announcements).orderBy(desc(announcements.publishedAt)).limit(3),
    db.select().from(matches).orderBy(asc(matches.date), asc(matches.id)).limit(5),
    db.select().from(tournaments).orderBy(asc(tournaments.date)),
  ]);
  return { news, fixtures, events };
}

export async function getAnnouncements(category?: string) {
  await ensureClubData();
  return db
    .select()
    .from(announcements)
    .where(category ? eq(announcements.category, category) : undefined)
    .orderBy(desc(announcements.publishedAt));
}

export async function getAnnouncement(slug: string) {
  await ensureClubData();
  const [article] = await db.select().from(announcements).where(eq(announcements.slug, slug)).limit(1);
  return article;
}

export async function getTournaments() {
  await ensureClubData();
  return db.select().from(tournaments).orderBy(asc(tournaments.date));
}

export async function getTournament(slug: string) {
  await ensureClubData();
  const [tournament] = await db.select().from(tournaments).where(eq(tournaments.slug, slug)).limit(1);
  return tournament;
}

export async function getTournamentRegistrationCount(slug: string) {
  const [result] = await db
    .select({ total: count() })
    .from(tournamentRegistrations)
    .where(eq(tournamentRegistrations.tournamentSlug, slug));
  return result?.total ?? 0;
}

export async function getMatches() {
  await ensureClubData();
  return db.select().from(matches).orderBy(asc(matches.date), asc(matches.id));
}
