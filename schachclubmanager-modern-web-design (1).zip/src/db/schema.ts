import {
  boolean,
  date,
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const announcements = pgTable("announcements", {
  slug: varchar("slug", { length: 180 }).primaryKey(),
  title: text("title").notNull(),
  category: varchar("category", { length: 60 }).notNull(),
  publishedAt: date("published_at", { mode: "string" }).notNull(),
  excerpt: text("excerpt").notNull(),
  body: text("body").notNull(),
  featured: boolean("featured").notNull().default(false),
});

export const tournaments = pgTable("tournaments", {
  slug: varchar("slug", { length: 180 }).primaryKey(),
  title: text("title").notNull(),
  date: date("date", { mode: "string" }).notNull(),
  time: varchar("time", { length: 20 }).notNull(),
  location: text("location").notNull(),
  format: varchar("format", { length: 80 }).notNull(),
  timeControl: varchar("time_control", { length: 100 }).notNull(),
  rounds: varchar("rounds", { length: 40 }).notNull(),
  description: text("description").notNull(),
  status: varchar("status", { length: 30 }).notNull().default("open"),
  capacity: integer("capacity").notNull().default(32),
});

export const matches = pgTable("matches", {
  id: varchar("id", { length: 80 }).primaryKey(),
  team: varchar("team", { length: 100 }).notNull(),
  opponent: varchar("opponent", { length: 160 }).notNull(),
  date: date("date", { mode: "string" }).notNull(),
  time: varchar("time", { length: 20 }).notNull(),
  location: varchar("location", { length: 160 }).notNull(),
  home: boolean("home").notNull().default(true),
});

export const membershipRequests = pgTable("membership_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  experience: varchar("experience", { length: 80 }).notNull(),
  message: text("message"),
  privacyAccepted: boolean("privacy_accepted").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const tournamentRegistrations = pgTable(
  "tournament_registrations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    tournamentSlug: varchar("tournament_slug", { length: 180 })
      .notNull()
      .references(() => tournaments.slug, { onDelete: "cascade" }),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 255 }).notNull(),
    club: varchar("club", { length: 160 }),
    privacyAccepted: boolean("privacy_accepted").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("tournament_registration_unique").on(table.tournamentSlug, table.email)],
);
