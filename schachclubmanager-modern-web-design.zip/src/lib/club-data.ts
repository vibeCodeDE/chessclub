import { db } from "@/db";
import { announcements, matches, tournamentRegistrations, tournaments } from "@/db/schema";
import { asc, count, desc, eq } from "drizzle-orm";

const announcementSeed: (typeof announcements.$inferInsert)[] = [
  {
    slug: "vereinsmeisterschaft-finale",
    title: "Ein Finale, das bis zum letzten Zug offen blieb",
    category: "Vereinsleben",
    publishedAt: "2026-09-27",
    excerpt:
      "Sieben Runden, ein halber Punkt Unterschied und jede Menge starke Partien: Unsere Vereinsmeisterschaft hat einen neuen Sieger.",
    body:
      "Am vergangenen Wochenende wurde unsere Vereinsmeisterschaft entschieden. Nach sieben Runden Schweizer System lagen die ersten drei Bretter nur einen halben Punkt auseinander. Entsprechend spannend wurde die Schlussrunde – und entsprechend lang wurde danach noch über die Partien gesprochen.\n\nWir gratulieren allen, die mitgespielt haben. Besonders schön war, dass erfahrene Turnierspielerinnen und neue Gesichter gemeinsam am Brett saßen. Genau so soll Vereinsmeisterschaft sein.\n\nDie nächste Ausgabe ist bereits in Planung. Wer beim nächsten Mal dabei sein möchte, ist beim Vereinsabend jederzeit willkommen.",
    featured: true,
  },
  {
    slug: "neue-trainingszeiten",
    title: "Neue Zeiten für unser Jugendtraining",
    category: "Jugend",
    publishedAt: "2026-09-18",
    excerpt:
      "Ab Oktober beginnen die jungen Schachfans schon um 17:30 Uhr. Das Training der Erwachsenen bleibt donnerstags um 19:00 Uhr.",
    body:
      "Damit unsere Jugendlichen nach dem Training früher zu Hause sind, beginnt das Jugendtraining ab Oktober bereits um 17:30 Uhr. Treffpunkt bleibt unser Vereinsheim in Musterstadt.\n\nDas offene Training und der Vereinsabend für Erwachsene starten weiterhin jeden Donnerstag um 19:00 Uhr. Eltern und Interessierte können ihre Kinder gern beim ersten Besuch begleiten.\n\nEine Anmeldung für ein erstes Kennenlernen ist nicht nötig. Bei Fragen schreibt uns einfach eine E-Mail an den Vorstand.",
  },
  {
    slug: "mannschaften-neue-saison",
    title: "Unsere Teams sind bereit für die neue Saison",
    category: "Spielbetrieb",
    publishedAt: "2026-09-09",
    excerpt:
      "Drei Mannschaften, viele neue Begegnungen: Im Oktober geht es für unsere Teams wieder an die Bretter.",
    body:
      "Die neue Ligasaison steht vor der Tür. Unsere erste Mannschaft geht mit einem frisch gemischten Kader in die Bezirksliga. Die zweite Mannschaft spielt in der Kreisklasse, unsere Jugend U16 sammelt Erfahrungen in der Jugendliga.\n\nOb Heimspiel oder Auswärtsfahrt: Wir freuen uns auf faire Begegnungen, knifflige Stellungen und die gemeinsamen Analysen danach. Die nächsten Termine findet ihr im Spielplan auf unserer Vereinsseite.\n\nWer einmal bei einem Heimspiel zuschauen möchte, kann einfach vorbeikommen.",
  },
  {
    slug: "rapidturnier-anmeldung",
    title: "Rapidturnier am Vereinsabend: Jetzt anmelden",
    category: "Turnier",
    publishedAt: "2026-08-31",
    excerpt:
      "Fünf Runden, 15 Minuten Bedenkzeit und ein guter Abend am Brett. Die Anmeldung für unser offenes Rapidturnier läuft.",
    body:
      "Unser offenes Rapidturnier findet wieder an einem Vereinsabend statt. Gespielt werden fünf Runden mit 15 Minuten Bedenkzeit pro Person. Das Turnier ist offen für Vereinsmitglieder und Gäste.\n\nLos geht es am Dienstag, den 20. Oktober 2026 um 19:00 Uhr im Vereinsheim Musterstadt. Bitte seid etwas früher da, damit wir pünktlich starten können.\n\nDie Plätze sind begrenzt. Ihr könnt euch direkt über die Turnierseite anmelden – wir freuen uns auf euch!",
  },
  {
    slug: "einladung-mitgliederversammlung",
    title: "Einladung zur Mitgliederversammlung",
    category: "Verein",
    publishedAt: "2026-08-22",
    excerpt:
      "Wir laden alle Mitglieder zur diesjährigen Versammlung im Vereinsheim ein. Die Tagesordnung folgt per E-Mail.",
    body:
      "Liebe Mitglieder, wir laden euch herzlich zu unserer diesjährigen Mitgliederversammlung im Vereinsheim ein. Auf der Tagesordnung stehen unter anderem der Rückblick auf die vergangene Saison und die Pläne für das kommende Vereinsjahr.\n\nDie genaue Tagesordnung und alle Unterlagen verschicken wir rechtzeitig per E-Mail an die Mitglieder. Wir freuen uns über eine rege Teilnahme und eure Ideen für unseren Club.\n\nBei Fragen könnt ihr euch jederzeit an den Vorstand wenden.",
  },
];

const tournamentSeed: (typeof tournaments.$inferInsert)[] = [
  {
    slug: "rapidturnier-am-vereinsabend",
    title: "Rapidturnier am Vereinsabend",
    date: "2026-10-20",
    time: "19:00",
    location: "Vereinsheim Musterstadt",
    format: "Rapidturnier",
    timeControl: "15 Minuten pro Person",
    rounds: "5 Runden",
    description:
      "Ein Abend, fünf Runden und viele gute Partien. Unser Rapidturnier ist offen für Mitglieder und Gäste – ganz gleich, ob du regelmäßig Turniere spielst oder zum ersten Mal dabei bist. Wir spielen in entspannter Atmosphäre mit 15 Minuten Bedenkzeit pro Person. Komm gern ein paar Minuten früher vorbei.",
    status: "open",
    capacity: 32,
  },
];

const matchSeed: (typeof matches.$inferInsert)[] = [
  {
    id: "2026-10-13-u16-rochade",
    team: "Jugend U16",
    opponent: "SC Rochade Süd",
    date: "2026-10-13",
    time: "14:00",
    location: "Auswärts",
    home: false,
  },
  {
    id: "2026-10-13-zweite-brettbrecher",
    team: "2. Mannschaft",
    opponent: "Brettbrecher Göttingen",
    date: "2026-10-13",
    time: "14:00",
    location: "Vereinsheim Musterstadt",
    home: true,
  },
  {
    id: "2026-10-13-erste-turmbau",
    team: "1. Mannschaft",
    opponent: "SC Turmbau",
    date: "2026-10-13",
    time: "14:00",
    location: "Vereinsheim Musterstadt",
    home: true,
  },
  {
    id: "2026-10-27-erste-brettbrecher",
    team: "1. Mannschaft",
    opponent: "Brettbrecher Göttingen",
    date: "2026-10-27",
    time: "18:30",
    location: "Auswärts",
    home: false,
  },
  {
    id: "2026-10-27-zweite-rochade",
    team: "2. Mannschaft",
    opponent: "SC Rochade Süd",
    date: "2026-10-27",
    time: "18:30",
    location: "Auswärts",
    home: false,
  },
];

let seedPromise: Promise<void> | undefined;

export async function ensureClubData() {
  if (!seedPromise) {
    seedPromise = (async () => {
      await db.insert(announcements).values(announcementSeed).onConflictDoNothing();
      await db.insert(tournaments).values(tournamentSeed).onConflictDoNothing();
      await db.insert(matches).values(matchSeed).onConflictDoNothing();
    })().catch((error) => {
      seedPromise = undefined;
      throw error;
    });
  }
  await seedPromise;
}

export async function getHomeData() {
  await ensureClubData();
  const [news, fixtures, events] = await Promise.all([
    db.select().from(announcements).orderBy(desc(announcements.publishedAt)).limit(3),
    db.select().from(matches).orderBy(asc(matches.date), asc(matches.id)).limit(5),
    db.select().from(tournaments).orderBy(asc(tournaments.date)),
  ]);
  return { news, fixtures, events };
}

export async function getAnnouncements(category?: string) {
  await ensureClubData();
  return db
    .select()
    .from(announcements)
    .where(category ? eq(announcements.category, category) : undefined)
    .orderBy(desc(announcements.publishedAt));
}

export async function getAnnouncement(slug: string) {
  await ensureClubData();
  const [article] = await db.select().from(announcements).where(eq(announcements.slug, slug)).limit(1);
  return article;
}

export async function getTournaments() {
  await ensureClubData();
  return db.select().from(tournaments).orderBy(asc(tournaments.date));
}

export async function getTournament(slug: string) {
  await ensureClubData();
  const [tournament] = await db.select().from(tournaments).where(eq(tournaments.slug, slug)).limit(1);
  return tournament;
}

export async function getTournamentRegistrationCount(slug: string) {
  const [result] = await db
    .select({ total: count() })
    .from(tournamentRegistrations)
    .where(eq(tournamentRegistrations.tournamentSlug, slug));
  return result?.total ?? 0;
}

export async function getMatches() {
  await ensureClubData();
  return db.select().from(matches).orderBy(asc(matches.date), asc(matches.id));
}
