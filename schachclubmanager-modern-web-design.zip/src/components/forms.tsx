"use client";

import Link from "next/link";
import { ArrowUpRight, Check } from "lucide-react";
import { useActionState } from "react";
import {
  submitMembershipRequest,
  submitTournamentRegistration,
  type FormState,
} from "@/app/actions";

const initialState: FormState = { status: "idle", message: "" };

function SuccessMessage({ message, linkHref, linkText }: { message: string; linkHref: string; linkText: string }) {
  return (
    <div className="form-success" role="status">
      <span className="success-icon"><Check size={25} strokeWidth={1.8} /></span>
      <h3>Das hat geklappt.</h3>
      <p>{message}</p>
      <Link href={linkHref} className="underlined-link">{linkText} <ArrowUpRight size={18} strokeWidth={1.8} /></Link>
    </div>
  );
}

export function MembershipForm() {
  const [state, action, pending] = useActionState(submitMembershipRequest, initialState);

  if (state.status === "success") {
    return <SuccessMessage message={state.message} linkHref="/verein" linkText="Mehr über den Verein erfahren" />;
  }

  return (
    <form action={action} className="club-form">
      <div className="form-row">
        <div className="form-field"><label htmlFor="membership-name">Dein Name <span>*</span></label><input id="membership-name" name="name" type="text" autoComplete="name" placeholder="Vor- und Nachname" maxLength={160} required /></div>
        <div className="form-field"><label htmlFor="membership-email">E-Mail-Adresse <span>*</span></label><input id="membership-email" name="email" type="email" autoComplete="email" placeholder="du@beispiel.de" maxLength={255} required /></div>
      </div>
      <div className="form-field"><label htmlFor="membership-experience">Deine Schacherfahrung <span>*</span></label><select id="membership-experience" name="experience" defaultValue="" required><option value="" disabled>Bitte auswählen</option><option value="Ich fange gerade an">Ich fange gerade an</option><option value="Ich spiele gelegentlich">Ich spiele gelegentlich</option><option value="Ich spiele schon im Verein">Ich spiele schon im Verein</option></select></div>
      <div className="form-field"><label htmlFor="membership-message">Noch etwas, das wir wissen sollten? <span className="optional">Optional</span></label><textarea id="membership-message" name="message" rows={4} maxLength={2000} placeholder="Deine Nachricht an uns …" /></div>
      <div className="trap-field" aria-hidden="true"><label htmlFor="membership-website">Website</label><input id="membership-website" name="website" type="text" tabIndex={-1} autoComplete="off" /></div>
      <label className="checkbox-field"><input type="checkbox" name="privacy" required /><span>Ich bin einverstanden, dass meine Angaben zur Beantwortung meiner Anfrage gespeichert und verarbeitet werden. Es erfolgt keine Weitergabe an Dritte. <strong>*</strong></span></label>
      {state.status === "error" && <p className="form-error" role="alert">{state.message}</p>}
      <button type="submit" className="button button-dark form-submit" disabled={pending}>{pending ? "Wird gesendet …" : "Anfrage senden"} <ArrowUpRight size={19} strokeWidth={1.8} /></button>
      <p className="form-note">* Pflichtfeld. Wir melden uns persönlich per E-Mail bei dir.</p>
    </form>
  );
}

export function TournamentRegistrationForm({ tournamentSlug }: { tournamentSlug: string }) {
  const [state, action, pending] = useActionState(submitTournamentRegistration, initialState);

  if (state.status === "success") {
    return <SuccessMessage message={state.message} linkHref="/turniere" linkText="Zur Turnierübersicht" />;
  }

  return (
    <form action={action} className="club-form">
      <input type="hidden" name="tournamentSlug" value={tournamentSlug} />
      <div className="form-row">
        <div className="form-field"><label htmlFor="tournament-name">Dein Name <span>*</span></label><input id="tournament-name" name="name" type="text" autoComplete="name" placeholder="Vor- und Nachname" maxLength={160} required /></div>
        <div className="form-field"><label htmlFor="tournament-email">E-Mail-Adresse <span>*</span></label><input id="tournament-email" name="email" type="email" autoComplete="email" placeholder="du@beispiel.de" maxLength={255} required /></div>
      </div>
      <div className="form-field"><label htmlFor="tournament-club">Verein <span className="optional">Optional</span></label><input id="tournament-club" name="club" type="text" placeholder="Dein Verein, falls vorhanden" maxLength={160} /></div>
      <div className="trap-field" aria-hidden="true"><label htmlFor="tournament-website">Website</label><input id="tournament-website" name="website" type="text" tabIndex={-1} autoComplete="off" /></div>
      <label className="checkbox-field"><input type="checkbox" name="privacy" required /><span>Ich bin einverstanden, dass meine Angaben zur Organisation des Turniers gespeichert und verarbeitet werden. Es erfolgt keine Weitergabe an Dritte. <strong>*</strong></span></label>
      {state.status === "error" && <p className="form-error" role="alert">{state.message}</p>}
      <button type="submit" className="button button-dark form-submit" disabled={pending}>{pending ? "Wird angemeldet …" : "Verbindlich anmelden"} <ArrowUpRight size={19} strokeWidth={1.8} /></button>
      <p className="form-note">* Pflichtfeld. Die Teilnahme ist offen für Mitglieder und Gäste.</p>
    </form>
  );
}
