import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-main">
        <div className="footer-brand-block">
          <Link className="footer-logo" href="/">
            <span aria-hidden="true">♞</span> Königsspringer<span className="footer-logo-period">.</span>
          </Link>
          <p>Ein guter Ort für alle, die Schach lieben. Und für alle, die es noch kennenlernen möchten.</p>
        </div>
        <div className="footer-column">
          <span className="footer-label">ENTDECKEN</span>
          <Link href="/aktuelles">Aktuelles</Link>
          <Link href="/turniere">Turniere</Link>
          <Link href="/verein">Der Verein</Link>
          <Link href="/mitglied-werden">Mitglied werden</Link>
        </div>
        <div className="footer-column">
          <span className="footer-label">VORBEIKOMMEN</span>
          <span>Vereinsheim Musterstadt</span>
          <span>Jugend · Do, 17:30 Uhr</span>
          <span>Vereinsabend · Do, 19:00 Uhr</span>
          <Link className="footer-mail" href="mailto:vorstand@koenigsspringer-musterstadt.de">
            E-Mail schreiben <ArrowUpRight size={15} />
          </Link>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Schachclub Königsspringer Musterstadt e.V.</span>
        <span>Mit Liebe zum Spiel. Ohne Tracker und externe Dienste.</span>
      </div>
    </footer>
  );
}
