import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { getHomeData } from "@/lib/club-data";
import { dateParts, formatDateWithMonth } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { news, fixtures, events } = await getHomeData();
  const nextEvent = events[0];
  const stats = [
    { number: "41", label: "MITGLIEDER", detail: "und ein gemeinsames Spiel" },
    { number: "03", label: "MANNSCHAFTEN", detail: "von Jugend bis Liga" },
    { number: String(events.length).padStart(2, "0"), label: "TURNIER GEPLANT", detail: "die nächste Chance für dich" },
    { number: String(fixtures.length).padStart(2, "0"), label: "LIGASPIELE", detail: "in den nächsten Wochen" },
  ];

  return (
    <main>
      <section className="home-hero" aria-labelledby="hero-title">
        <div className="container hero-grid">
          <div className="hero-copy">
            <div className="eyebrow hero-eyebrow"><span className="eyebrow-dot" /> SCHACHCLUB KÖNIGSSPRINGER · MUSTERSTADT</div>
            <h1 id="hero-title">Schach ist am schönsten <em>zusammen.</em></h1>
            <p className="hero-intro">Ob dein erster Zug oder deine nächste Meisterschaft: Hier findest du Menschen, die deine Begeisterung teilen.</p>
            <div className="hero-actions">
              <Link href="/verein" className="button button-dark">Verein entdecken <ArrowUpRight size={19} strokeWidth={1.8} /></Link>
              <Link href="/mitglied-werden" className="underlined-link">Mitglied werden <ArrowUpRight size={17} strokeWidth={1.8} /></Link>
            </div>
            <div className="hero-footnote"><span className="footnote-line" /> Ein Platz am Brett ist immer frei.</div>
          </div>
          <div className="hero-media">
            <div className="hero-image-frame">
              <Image
                src="/images/chess-game.jpg"
                alt="Eine Schachpartie am Brett: eine Hand setzt die nächste Figur"
                fill
                priority
                sizes="(max-width: 850px) 100vw, 50vw"
                className="cover-image hero-image"
              />
              <span className="image-side-note">KÖNIGSSPRINGER / MUSTERSTADT</span>
            </div>
            {nextEvent && (
              <Link href={`/turniere/${nextEvent.slug}`} className="hero-event-card">
                <span className="event-card-top">ALS NÄCHSTES IM CLUB <ArrowUpRight size={18} strokeWidth={1.7} /></span>
                <strong>{nextEvent.title}</strong>
                <span className="event-card-date">{formatDateWithMonth(nextEvent.date)} · {nextEvent.time} Uhr</span>
              </Link>
            )}
          </div>
        </div>
      </section>

      <section className="weekly-band" aria-label="Vereinsabend">
        <div className="container weekly-inner">
          <span className="weekly-label"><span className="status-dot" /> JEDE WOCHE AM BRETT</span>
          <strong>Donnerstags ist Vereinsabend.</strong>
          <span className="weekly-detail"><Clock3 size={17} strokeWidth={1.7} /> Ab 19:00 Uhr</span>
          <span className="weekly-detail"><MapPin size={17} strokeWidth={1.7} /> Vereinsheim Musterstadt</span>
          <Link href="/verein#training" aria-label="Mehr zum Vereinsabend"><ArrowUpRight size={21} strokeWidth={1.7} /></Link>
        </div>
      </section>

      <section className="overview-section section-space" aria-labelledby="overview-title">
        <div className="container">
          <div className="section-heading-row">
            <div><div className="eyebrow section-eyebrow"><span className="small-rule" /> UNSER VEREIN</div><h2 id="overview-title" className="section-title">Auf einen <em>Blick.</em></h2></div>
            <p className="section-aside">Gemeinsam spielen, lernen und wachsen. <br />Saison 2026/27.</p>
          </div>
          <div className="stats-grid">
            {stats.map((stat) => (
              <div className="stat-item" key={stat.label}>
                <strong>{stat.number}</strong>
                <span className="stat-label">{stat.label}</span>
                <span className="stat-detail">{stat.detail}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="updates-section section-space" aria-labelledby="updates-title">
        <div className="container">
          <div className="section-heading-row updates-heading">
            <div><div className="eyebrow section-eyebrow"><span className="small-rule" /> IM CLUB</div><h2 id="updates-title" className="section-title">Neues vom <em>Brett.</em></h2></div>
            <Link className="section-more" href="/aktuelles">Alle Neuigkeiten <ArrowUpRight size={19} strokeWidth={1.7} /></Link>
          </div>
          <div className="updates-grid">
            <div className="news-list">
              {news.map((article) => {
                const date = dateParts(article.publishedAt);
                return (
                  <Link className="news-row" href={`/aktuelles/${article.slug}`} key={article.slug}>
                    <time dateTime={article.publishedAt} className="news-date"><strong>{date.day}</strong><span>{date.month}</span></time>
                    <div className="news-content">
                      <span className="item-kicker">{article.category} <span>·</span> {formatDateWithMonth(article.publishedAt)}</span>
                      <h3>{article.title}</h3>
                      <p>{article.excerpt}</p>
                    </div>
                    <ArrowUpRight className="news-arrow" size={21} strokeWidth={1.6} aria-hidden="true" />
                  </Link>
                );
              })}
              <Link className="news-bottom-link" href="/aktuelles">Weitere Geschichten lesen <ArrowRight size={18} strokeWidth={1.7} /></Link>
            </div>
            <aside className="fixtures-panel" aria-labelledby="fixtures-title">
              <div className="fixtures-heading"><span className="eyebrow">SPIELPLAN / 2026–27</span><h3 id="fixtures-title">Die nächsten <em>Begegnungen.</em></h3></div>
              <div className="fixture-list">
                {fixtures.slice(0, 3).map((match) => {
                  const date = dateParts(match.date);
                  return (
                    <div className="fixture-item" key={match.id}>
                      <time dateTime={match.date} className="fixture-date"><strong>{date.day}</strong><span>{date.month}</span></time>
                      <div><span className="fixture-team">{match.team}</span><strong className="fixture-opponent">gegen {match.opponent}</strong><span className="fixture-meta">{match.time} Uhr · {match.home ? "Heimspiel" : "Auswärts"}</span></div>
                    </div>
                  );
                })}
              </div>
              <Link href="/verein#spielplan" className="fixtures-link">Zum Spielplan <ArrowUpRight size={18} strokeWidth={1.7} /></Link>
            </aside>
          </div>
        </div>
      </section>

      {nextEvent && (
        <section className="featured-section section-space" aria-labelledby="featured-title">
          <div className="container feature-grid">
            <div className="feature-copy">
              <div className="eyebrow feature-eyebrow"><span className="eyebrow-dot" /> NÄCHSTES TURNIER · {formatDateWithMonth(nextEvent.date).toUpperCase()}</div>
              <h2 id="featured-title">Ein Abend.<br /><em>Viele gute Züge.</em></h2>
              <p>{nextEvent.description}</p>
              <div className="feature-facts"><span>{nextEvent.rounds}</span><span>{nextEvent.timeControl}</span><span>Offen für alle</span></div>
              <Link href={`/turniere/${nextEvent.slug}`} className="button button-lime">Zum Turnier & anmelden <ArrowUpRight size={19} strokeWidth={1.8} /></Link>
            </div>
            <div className="feature-photo">
              <Image src="/images/chess-pieces.jpg" alt="Schachfiguren auf einem Spielbrett" fill sizes="(max-width: 850px) 100vw, 45vw" className="cover-image" />
              <span className="photo-caption">01 / GEMEINSAM SPIELEN</span>
            </div>
          </div>
        </section>
      )}

      <section className="join-section section-space" aria-labelledby="join-title">
        <div className="container join-grid">
          <div className="join-photo"><Image src="/images/chess-community.jpg" alt="Zwei Menschen spielen gemeinsam eine Partie Schach" fill sizes="(max-width: 850px) 100vw, 45vw" className="cover-image" /></div>
          <div className="join-copy">
            <div className="eyebrow section-eyebrow"><span className="small-rule" /> DEIN PLATZ IM CLUB</div>
            <h2 id="join-title">Neugierig?<br /><em>Spiel mit.</em></h2>
            <p>Du musst keine Eröffnung auswendig können, um bei uns richtig zu sein. Komm vorbei, spiel eine Partie und lern uns kennen.</p>
            <div className="join-time"><span>JUGENDTRAINING</span><strong>Donnerstags · 17:30 Uhr</strong></div>
            <div className="join-time"><span>VEREINSABEND</span><strong>Donnerstags · 19:00 Uhr</strong></div>
            <Link href="/mitglied-werden" className="button button-dark">Mitglied werden <ArrowUpRight size={19} strokeWidth={1.8} /></Link>
          </div>
        </div>
      </section>
    </main>
  );
}
