import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { MembershipForm } from "@/components/forms";

export const metadata: Metadata = { title: "Mitglied werden", description: "Lerne den Schachclub Königsspringer kennen und schick uns deine unverbindliche Anfrage." };

export default function MembershipPage() {
  return (
    <main className="inner-page membership-page">
      <section className="page-intro container">
        <Link href="/" className="back-link"><ArrowLeft size={17} strokeWidth={1.7} /> Startseite</Link>
        <div className="eyebrow section-eyebrow"><span className="small-rule" /> MITGLIED WERDEN</div>
        <h1>Dein Platz am Brett <em>wartet.</em></h1>
        <p>Ob du gerade die Regeln lernst oder schon lange spielst: Schön, dass du da bist.</p>
      </section>
      <section className="container membership-layout" aria-labelledby="membership-heading">
        <div className="membership-info">
          <div className="eyebrow section-eyebrow"><span className="small-rule" /> GANZ UNKOMPLIZIERT</div>
          <h2 id="membership-heading">In drei Zügen <em>dabei.</em></h2>
          <div className="step-list"><div className="step-item"><span>01</span><div><h3>Schreib uns</h3><p>Erzähl uns kurz, wer du bist und wie du Schach spielst. Anfängerinnen und Anfänger sind genauso willkommen.</p></div></div><div className="step-item"><span>02</span><div><h3>Komm vorbei</h3><p>Lern uns beim Vereinsabend kennen. Spiel eine Partie, stell Fragen und fühl dich einfach wohl.</p></div></div><div className="step-item"><span>03</span><div><h3>Bleib am Brett</h3><p>Wenn es für dich passt, besprechen wir alles Weitere rund um die Mitgliedschaft persönlich.</p></div></div></div>
          <div className="membership-visit"><span className="eyebrow">LIEBER DIREKT VORBEIKOMMEN?</span><p><Clock3 size={18} strokeWidth={1.7} /> Donnerstags ab 19:00 Uhr</p><p><MapPin size={18} strokeWidth={1.7} /> Vereinsheim Musterstadt</p><Link href="mailto:vorstand@koenigsspringer-musterstadt.de">Oder schreib uns eine E-Mail <ArrowUpRight size={17} strokeWidth={1.7} /></Link></div>
        </div>
        <div className="membership-form-panel"><span className="eyebrow">SAG EINFACH HALLO</span><h2>Wir freuen uns <em>auf dich.</em></h2><p>Schick uns eine Nachricht. Wir antworten dir persönlich und klären alles Weitere gemeinsam.</p><MembershipForm /></div>
      </section>
    </main>
  );
}
