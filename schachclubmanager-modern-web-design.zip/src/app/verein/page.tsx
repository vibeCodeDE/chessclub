import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight, MapPin } from "lucide-react";
import { getMatches } from "@/lib/club-data";
import { dateParts, formatDate } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Der Verein", description: "Training, Mannschaften und Vereinsleben beim Schachclub Königsspringer Musterstadt." };

export default async function ClubPage() {
  const fixtures = await getMatches();

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link"><ArrowLeft size={17} strokeWidth={1.7} /> Startseite</Link>
        <div className="eyebrow section-eyebrow"><span className="small-rule" /> DAS SIND WIR</div>
        <h1>Ein Club für <em>alle Züge.</em></h1>
        <p>Wir mögen gute Partien. Noch lieber mögen wir die Menschen, mit denen wir sie spielen.</p>
      </section>
      <section className="container club-story-grid" aria-labelledby="story-title">
        <div className="club-story-photo"><Image src="/images/chess-community.jpg" alt="Zwei Spieler konzentrieren sich auf eine gemeinsame Schachpartie" fill sizes="(max-width: 850px) 100vw, 50vw" className="cover-image" /><span>MEHR ALS 64 FELDER</span></div>
        <div className="club-story-copy"><div className="eyebrow section-eyebrow"><span className="small-rule" /> KÖNIGSSPRINGER MUSTERSTADT</div><h2 id="story-title">Das Spiel bringt uns <em>zusammen.</em></h2><p>Bei uns sitzen Neulinge neben alten Hasen, Jugendliche neben Erwachsenen. Wir trainieren, spielen Turniere, fiebern mit unseren Mannschaften mit – und nehmen uns immer Zeit für eine Partie zwischendurch.</p><p>Ob du ehrgeizig Punkte sammeln oder einfach in guter Gesellschaft Schach spielen möchtest: Du bist willkommen.</p><Link href="/mitglied-werden" className="underlined-link">Lerne uns kennen <ArrowUpRight size={18} strokeWidth={1.7} /></Link></div>
      </section>
      <section className="training-section section-space" id="training" aria-labelledby="training-title"><div className="container"><div className="section-heading-row"><div><div className="eyebrow section-eyebrow"><span className="small-rule" /> JEDE WOCHE</div><h2 id="training-title" className="section-title">Zeit für <em>Schach.</em></h2></div><p className="section-aside">Komm einfach vorbei und spiel mit. <br />Wir freuen uns auf neue Gesichter.</p></div><div className="training-grid"><div className="training-item"><span className="training-number">01 / JUGEND</span><h3>Jugendtraining</h3><strong>Donnerstags <em>17:30 Uhr</em></strong><p>Gemeinsam lernen, ausprobieren und besser werden. Für junge Schachbegeisterte aller Spielstärken.</p></div><div className="training-item"><span className="training-number">02 / ALLE</span><h3>Offener Vereinsabend</h3><strong>Donnerstags <em>19:00 Uhr</em></strong><p>Freie Partien, Training und Austausch. Für Mitglieder, Neugierige und alle dazwischen.</p></div><div className="training-location"><MapPin size={24} strokeWidth={1.5} /><span>WO WIR SPIELEN</span><strong>Vereinsheim<br />Musterstadt</strong><p>Du bist zum ersten Mal da? Sag einfach Hallo – wir finden ein passendes Brett für dich.</p></div></div></div></section>
      <section className="container schedule-section section-space" id="spielplan" aria-labelledby="schedule-title"><div className="section-heading-row"><div><div className="eyebrow section-eyebrow"><span className="small-rule" /> SAISON 2026 / 27</div><h2 id="schedule-title" className="section-title">Auf dem <em>Spielplan.</em></h2></div><p className="section-aside">Die nächsten Begegnungen unserer drei Mannschaften.</p></div><div className="schedule-table"><div className="schedule-head"><span>TERMIN</span><span>MANNSCHAFT</span><span>BEGEGNUNG</span><span>UHRZEIT / ORT</span></div>{fixtures.map((match) => { const date = dateParts(match.date); return <div className="schedule-row" key={match.id}><time dateTime={match.date} className="schedule-date"><strong>{date.day}</strong><span>{date.month} <small>{match.date.slice(0,4)}</small></span></time><strong className="schedule-team">{match.team}</strong><span className="schedule-opponent">{match.home ? "gegen" : "bei"} {match.opponent}</span><span className="schedule-place">{formatDate(match.date)} · {match.time} Uhr<br /><small>{match.home ? "Heimspiel" : "Auswärts"}</small></span></div>; })}</div></section>
      <section className="container club-bottom-cta"><div><span className="eyebrow">DEIN NÄCHSTER ZUG</span><h2>Einfach mal <em>vorbeischauen.</em></h2><p>Du brauchst keine Anmeldung für einen ersten Besuch. Wir freuen uns, dich kennenzulernen.</p></div><Link href="/mitglied-werden" className="button button-lime">Kontakt aufnehmen <ArrowRight size={19} strokeWidth={1.7} /></Link></section>
    </main>
  );
}
