import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/dm-sans/index.css";
import "@fontsource/instrument-serif/400.css";
import "@fontsource/instrument-serif/400-italic.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Schachclub Königsspringer | Schach in Musterstadt",
    template: "%s | Schachclub Königsspringer",
  },
  description:
    "Schach spielen, Menschen treffen, gemeinsam besser werden. Neuigkeiten, Turniere und Vereinsleben beim Schachclub Königsspringer Musterstadt.",
  openGraph: {
    title: "Schachclub Königsspringer Musterstadt",
    description: "Ein Club. Viele gute Züge. Entdecke unseren Schachverein in Musterstadt.",
    type: "website",
    locale: "de_DE",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="de">
      <body>
        <SiteHeader />
        {children}
        <SiteFooter />
      </body>
    </html>
  );
}
