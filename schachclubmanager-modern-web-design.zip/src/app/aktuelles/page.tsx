import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight } from "lucide-react";
import { getAnnouncements } from "@/lib/club-data";
import { dateParts, formatDateWithMonth } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Aktuelles", description: "Geschichten, Neuigkeiten und Ankündigungen aus dem Schachclub Königsspringer." };

const categories = ["Alle", "Vereinsleben", "Jugend", "Spielbetrieb", "Turnier", "Verein"];

type Props = { searchParams: Promise<{ thema?: string }> };

export default async function NewsPage({ searchParams }: Props) {
  const { thema } = await searchParams;
  const active = thema && categories.includes(thema) ? thema : "Alle";
  const articles = await getAnnouncements(active === "Alle" ? undefined : active);

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link"><ArrowLeft size={17} strokeWidth={1.7} /> Startseite</Link>
        <div className="eyebrow section-eyebrow"><span className="small-rule" /> AUS DEM VEREIN</div>
        <h1>Was uns <em>bewegt.</em></h1>
        <p>Partien, Menschen und alles dazwischen. Hier erzählen wir, was bei Königsspringer gerade passiert.</p>
      </section>
      <section className="container index-section" aria-label="Neuigkeiten">
        <div className="filter-bar">
          <span>THEMEN</span>
          <div className="filter-links" aria-label="Nach Thema filtern">
            {categories.map((category) => (
              <Link key={category} href={category === "Alle" ? "/aktuelles" : `/aktuelles?thema=${encodeURIComponent(category)}`} className={active === category ? "selected" : ""} aria-current={active === category ? "page" : undefined}>{category}</Link>
            ))}
          </div>
        </div>
        <div className="index-grid">
          <div className="news-list index-news-list">
            {articles.map((article) => {
              const date = dateParts(article.publishedAt);
              return (
                <Link className="news-row" href={`/aktuelles/${article.slug}`} key={article.slug}>
                  <time dateTime={article.publishedAt} className="news-date"><strong>{date.day}</strong><span>{date.month}</span></time>
                  <div className="news-content"><span className="item-kicker">{article.category} <span>·</span> {formatDateWithMonth(article.publishedAt)}</span><h2>{article.title}</h2><p>{article.excerpt}</p></div>
                  <ArrowUpRight className="news-arrow" size={21} strokeWidth={1.6} aria-hidden="true" />
                </Link>
              );
            })}
            {articles.length === 0 && <p className="empty-message">Zu diesem Thema gibt es noch keine Beiträge.</p>}
          </div>
          <aside className="index-aside">
            <span className="eyebrow">GUT ZU WISSEN</span>
            <span className="aside-symbol" aria-hidden="true">♞</span>
            <h2>Die besten Geschichten entstehen nach der Partie.</h2>
            <p>Donnerstags ab 19 Uhr sitzen wir gemeinsam am Brett. Neue Gesichter sind immer willkommen.</p>
            <Link className="underlined-link" href="/verein#training">Vereinsabend entdecken <ArrowRight size={17} strokeWidth={1.7} /></Link>
          </aside>
        </div>
      </section>
    </main>
  );
}
