import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight, CalendarDays, Clock3, MapPin, Timer, UsersRound } from "lucide-react";
import { TournamentRegistrationForm } from "@/components/forms";
import { getTournament, getTournamentRegistrationCount } from "@/lib/club-data";
import { dateParts, formatLongDate } from "@/lib/format";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const tournament = await getTournament(slug);
  return { title: tournament?.title ?? "Turnier nicht gefunden", description: tournament?.description };
}

export default async function TournamentDetailPage({ params }: Props) {
  const { slug } = await params;
  const tournament = await getTournament(slug);
  if (!tournament) notFound();
  const registered = await getTournamentRegistrationCount(slug);
  const spotsLeft = Math.max(0, tournament.capacity - registered);
  const isOpen = tournament.status === "open" && spotsLeft > 0;
  const date = dateParts(tournament.date);

  return (
    <main className="inner-page tournament-detail">
      <div className="container"><Link href="/turniere" className="back-link tournament-back"><ArrowLeft size={17} strokeWidth={1.7} /> Alle Turniere</Link></div>
      <section className="container tournament-detail-hero">
        <div className="tournament-hero-copy"><span className="eyebrow"><span className="eyebrow-dot" /> OFFENES TURNIER / SAISON 2026–27</span><h1>{tournament.title}</h1><p>Ein guter Abend beginnt mit einem Zug. Wir freuen uns auf bekannte Gesichter und neue Gegnerinnen und Gegner.</p>{isOpen && <Link href="#anmeldung" className="button button-lime">Jetzt anmelden <ArrowUpRight size={19} strokeWidth={1.8} /></Link>}</div>
        <div className="tournament-hero-date"><span className="hero-date-top">SAVE THE DATE</span><strong>{date.day}</strong><span className="hero-date-month">{date.month} / {tournament.date.slice(0, 4)}</span><span className="hero-date-knight" aria-hidden="true">♞</span></div>
      </section>
      <section className="container tournament-details-grid">
        <div className="tournament-description"><div className="eyebrow section-eyebrow"><span className="small-rule" /> DAS ERWARTET DICH</div><h2>Schach. Spannung.<br /><em>Zusammensein.</em></h2><p>{tournament.description}</p><p>Du brauchst nur Freude am Spiel mitzubringen. Um alles andere kümmern wir uns vor Ort.</p></div>
        <div className="tournament-facts"><h3>Alles auf einen Blick</h3><div className="fact-row"><CalendarDays size={21} strokeWidth={1.5} /><div><span>TERMIN</span><strong>{formatLongDate(tournament.date)}</strong></div></div><div className="fact-row"><Clock3 size={21} strokeWidth={1.5} /><div><span>BEGINN</span><strong>{tournament.time} Uhr</strong></div></div><div className="fact-row"><MapPin size={21} strokeWidth={1.5} /><div><span>ORT</span><strong>{tournament.location}</strong></div></div><div className="fact-row"><Timer size={21} strokeWidth={1.5} /><div><span>MODUS</span><strong>{tournament.rounds} · {tournament.timeControl}</strong></div></div><div className="fact-row"><UsersRound size={21} strokeWidth={1.5} /><div><span>TEILNAHME</span><strong>Offen für Mitglieder und Gäste</strong></div></div></div>
      </section>
      <section className="registration-section" id="anmeldung" aria-labelledby="registration-title"><div className="container registration-grid"><div className="registration-main"><div className="eyebrow section-eyebrow"><span className="small-rule" /> DEIN PLATZ AM BRETT</div><h2 id="registration-title">Sei <em>dabei.</em></h2><p>Fülle das Formular aus und sichere dir deinen Platz beim {tournament.title}.</p>{isOpen ? <TournamentRegistrationForm tournamentSlug={tournament.slug} /> : <div className="closed-notice">Die Anmeldung für dieses Turnier ist leider geschlossen. Schau bei unseren nächsten Terminen wieder vorbei.</div>}</div><aside className="registration-aside"><span className="eyebrow">ANMELDUNG</span><strong>{spotsLeft.toString().padStart(2, "0")}</strong><span>Plätze noch frei</span><div className="registration-aside-rule" /><p>Du hast noch eine Frage zum Turnier oder zur Anmeldung?</p><Link href="mailto:vorstand@koenigsspringer-musterstadt.de">Schreib uns <ArrowUpRight size={17} strokeWidth={1.7} /></Link></aside></div></section>
    </main>
  );
}
