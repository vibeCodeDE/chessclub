import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ArrowRight, ArrowUpRight, Clock3, MapPin } from "lucide-react";
import { getTournaments } from "@/lib/club-data";
import { dateParts, formatLongDate } from "@/lib/format";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Turniere", description: "Turniere, Termine und Anmeldung beim Schachclub Königsspringer Musterstadt." };

export default async function TournamentsPage() {
  const events = await getTournaments();

  return (
    <main className="inner-page">
      <section className="page-intro container">
        <Link href="/" className="back-link"><ArrowLeft size={17} strokeWidth={1.7} /> Startseite</Link>
        <div className="eyebrow section-eyebrow"><span className="small-rule" /> TERMINE & TURNIERE</div>
        <h1>Dein nächster <em>Zug.</em></h1>
        <p>Ein Turnier ist mehr als ein Ergebnis. Es sind neue Begegnungen, spannende Partien und gute Geschichten danach.</p>
      </section>
      <section className="container tournament-index" aria-labelledby="tournament-list-title">
        <div className="index-label-row"><span id="tournament-list-title">ANSTEHENDE TURNIERE</span><span>SAISON 2026 / 27</span></div>
        {events.map((event) => {
          const date = dateParts(event.date);
          return (
            <article className="tournament-index-item" key={event.slug}>
              <div className="tournament-date-large"><strong>{date.day}</strong><span>{date.month} / {event.date.slice(0, 4)}</span></div>
              <div className="tournament-index-copy"><span className="item-kicker"><span className="open-dot" /> ANMELDUNG {event.status === "open" ? "OFFEN" : "GESCHLOSSEN"} · {event.format.toUpperCase()}</span><h2>{event.title}</h2><p>{event.description}</p><div className="tournament-inline-facts"><span><Clock3 size={16} strokeWidth={1.7} /> {formatLongDate(event.date)} · {event.time} Uhr</span><span><MapPin size={16} strokeWidth={1.7} /> {event.location}</span></div></div>
              <Link href={`/turniere/${event.slug}`} className="round-arrow" aria-label={`${event.title} ansehen`}><ArrowUpRight size={26} strokeWidth={1.5} /></Link>
            </article>
          );
        })}
        {events.length === 0 && <p className="empty-message">Aktuell sind keine Turniere geplant. Schau bald wieder vorbei.</p>}
      </section>
      <section className="container tournament-bottom-note"><div><span className="eyebrow">GUT ZU WISSEN</span><h2>Alle Spielstärken sind willkommen.</h2><p>Du brauchst keine Turniererfahrung, um mitzumachen. Bei Fragen zum Ablauf schreib uns einfach – oder schau donnerstags beim Vereinsabend vorbei.</p></div><Link href="mailto:vorstand@koenigsspringer-musterstadt.de" className="underlined-link">Frage stellen <ArrowRight size={18} strokeWidth={1.7} /></Link></section>
    </main>
  );
}
